﻿/*
 * (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
 * Snegopat Engine main file
 * Основная точка входа. Вызывается в момент, когда snegopat.dll средствами WinAPI
 * отловил создание окна заставки 1С, но она еще не показана. Все 1С-ные дллки загружены.
 * однако часть функций вызывать еще небезопасно, так как часть инициализации 1С происходит
 * после создания основного окна. Поэтому сейчас надо инициализировать то, что нужно и можно
 * до создания основного окна, и отлавливать его создание, дабы запустить всё остальное
 */

// Данные строки нужны только для среды разработки и вырезаются препроцессором
#pragma once
#include "../all.h"

string sv8ver;
string myFolder;
string ownerName;
string snegoVersion;
string activeAddin;

uint64 v8ver;

// Поддерживаемые платформы 8.3.<выпуск>: от 17 до 27 включительно (решение владельца 2026-10-25). Проверены 8.3.17 и 8.3.27, промежуточные пускаем.
// Вне диапазона движок не стартует: перехваты привязаны к внутренним структурам этих сборок, на чужой платформе они падают или молча
// не работают (8.3.13: пять аддинов падают при загрузке, меню не добавляется). Вместо этого — запись в журнал и уведомление в трее
// (его показывает стартер) при каждом запуске. Снять проверку: logs\diag.ini, platform.check=off (реестр: tools/DISABLED-27.md).
const int platformMinRelease = 17;
const int platformMaxRelease = 27;
// 8.5: проверены сборки 8.5.1.1529 (запуск, мост, настройки; 2026-10-27) и 8.5.1.1343 (G3, 2026-10-28: запуск, мост, метаданные, окна, заголовки
// представлений, текстовые окна). Запуск на 8.5 держится на бинарном патче окна snegopat.dll (tools/patch_snegopat_window.py). С 2026-11-06 пускаем любую
// сборку 8.5.1.x (в том числе 1302 у клиента «Осминог»), непроверенные сборки на риске владельца.
const int platform85Release = 1;
StarterInterProcess&& platformGateIpc;

bool platformSupported() {
    diagReload();
    string check = diagGet("platform.check");
    if (check == "off" || check == "0" || check == "no")
        return true;
    int major = int(v8ver >> 48) & 0xFFFF;
    int minor = int(v8ver >> 32) & 0xFFFF;
    int release = int(v8ver >> 16) & 0xFFFF;
    if (major == 8 && minor == 5) {
        // любая сборка 8.5.1.x (решение владельца 2026-11-06; проверены 1343 и 1529, 1302 пускаем по этому решению)
        return release == platform85Release;
    }
    return major == 8 && minor == 3 && release >= platformMinRelease && release <= platformMaxRelease;
}

void platformRejected() {
    string text = "Платформа " + sv8ver + " не поддерживается, Снегопат не запущен (нужна 8.3." + platformMinRelease + " - 8.3." + platformMaxRelease + " или 8.5." + platform85Release + ".x)";
    diagAlways("start", text + "; снять проверку: platform.check=off в diag.ini");
    &&platformGateIpc = StarterInterProcess("SnegopatGate", function(const string& data) {});
    platformGateIpc.showNotify("Снегопат", text);
}

// Вызывается из snegopat.dll в момент создания окна заставки 1С
void run() {
    myFolder = env.moduleDir;
    v8ver = env.processVersion;
    ownerName = env.ownerName;
    snegoVersion = env.strCoreAsVersion;

    sv8ver = "" + (int(v8ver >> 48) & 0xFFFF) + "." + (int(v8ver >> 32) & 0xFFFF) + "." +
        (int(v8ver >> 16) & 0xFFFF) + "." + (int(v8ver >> 0) & 0xFFFF);

    if (!platformSupported()) {
        platformRejected();
        return;
    }
    diagBanner();
    // замер этапов старта (diag.ini: startup.timing=on)
    uint tm0 = GetTickCount();
    initSymbolClassTable();
    uint tm1 = GetTickCount();
    initPathes();
    uint tm2 = GetTickCount();
    initSnegopatProfile();
    uint tm3 = GetTickCount();
    initWorkWithMainFrame();
    uint tm4 = GetTickCount();
    if (diagGet("startup.timing") == "on")
        diagAlways("timing", "run: таблица символов " + (tm1 - tm0) + " мс, пути " + (tm2 - tm1) + " мс, профиль " + (tm3 - tm2) + " мс, главное окно " + (tm4 - tm3) + " мс");
    //initTextAreaModifiedTraps();
}

// Вызывается из Core.As в момент загрузки модуля.
int main(array<string>&& cmdArgs) {
    return 0;
}


// Заполняем таблицу, в которой указан класс символа. Таблица используется в snegopat.dll, но
// для заполнения используются функции V*.
void initSymbolClassTable() {
    for (uint k = 0; k <= 32; k++)
        mem::byte[symbolClassTable + k] = symbSpace;
    for (uint k = 33; k < 0x10000; k++) {
        if (is_space(k))
            mem::byte[symbolClassTable + k] = symbSpace;
        else if (is_alpha(k))
            mem::byte[symbolClassTable + k] = symbAlpha;
    }
}

TrapVirtualStdCall trProfileOpen;
// Настройки Снегопата лежат в своих файлах data\Snegopat\settings\*.set (settings_store.as) и к профилю платформы не подключаются.
// Перехват открытия профиля нужен, чтобы сразу после открытия прочитать настройки движка и запустить пакеты.
// Папка data должна быть доступна для записи.
void initSnegopatProfile() {
    trProfileOpen.setTrap(getProfileService(), IProfileService_open, IProfileService_openTrap);
}

void IProfileService_openTrap(IProfileService& ps) {
    trProfileOpen.swap();
    CreateDirectory(pathes._data.cstr, 0);
    ps.open();
    initAllOption();
    // Инициализируем пакеты
    initPackets(piOnMainEnter);
}

Packet pktTxtWork("TxtWork", setTextHooks, piOnMainEnter);
bool enableTextWork;
OptionsEntry oeEnableTextWork("EnableTextWork", function(v){v = true; },
    function(v){v.getBoolean(enableTextWork); },
    function(v){v.getBoolean(enableTextWork); setTextHooks(); if (enableTextWork) Message("Подсказка снегопата заработает только во вновь открытых окнах"); return false; });

// Установка различных перехватов, связанных с текстовыми окнами/документами
bool setTextHooks() {
    // Диагностика: diag.ini, hook.txtwork=off отключает все перехваты текстовых окон (для бисекции сбоев на новой платформе)
    if (!diagHook("txtwork", true))
        return true;
    if (!enableTextWork) {
        disableAllTextTraps();
        textDocStorage.disableTextWork();
        return true;
    }
    // Надо установить перехват на создании окон Text control и text view.
    // Объект TextCtrl можно создать прямо сейчас и установить перехват в его виртуальной таблице
    if (trTxtEdtCtrl_createWnd.state == trapNotActive) {
        IWindowView&& wnd;
        currentProcess().createByClsid(CLSID_TxtEdtCtrl, IID_IWindowView, wnd);
        dbgLog(wnd is null ? "setTextHooks: TxtEdtCtrl IWindowView НЕ создан" : "setTextHooks: TxtEdtCtrl IWindowView создан");
        if (wnd is null)
            Print("Не удалось создать TxtEdtCtrl IWindowView");
        else {
            trTxtEdtCtrl_createWnd.setTrap(&&wnd, IWindowView_createWindow, TxtEdtCtrl_createWindow);
            dbgLog("setTextHooks: trap createWnd(ctrl) state=" + trTxtEdtCtrl_createWnd.state + " слот=" + IWindowView_createWindow);
            ICommandTarget&& tgt = wnd.unk;
            if (tgt is null)
                Print("Не удалось получить ICommandTarget из TxtEdtCtrl IWindowView");
            else // Ставим перехват на получение окном текстового контрола команды
                trTxtCtrCommand_onExecute.setTrap(&&tgt, ICommandTarget_onExecute, TxtCtrCommand_onExecute);
        }
        // Теперь установим перехват на назначение текстового расширения текстовому документу
        IDocument&& doc;
        currentProcess().createByClsid(CLSID_TxtEdtDoc, IID_IDocument, doc);
        dbgLog(doc is null ? "setTextHooks: TxtEdtDoc IDocument НЕ создан" : "setTextHooks: TxtEdtDoc IDocument создан");
        if (doc is null)
            Print("Не удалось создать TxtEdtDoc IDocument");
        else {
            ITextManager_Operations&& to = doc.unk;
            if (to is null)
                Print("Не удалось получить ITextManager_Operations из TxtEdtDoc");
            else
                trTxtMgr_setExtender.setTrap(&&to, ITextManager_Operations_setExtenderCLSID, TxtMgrOper_setExtender);
            // Далее устанавливаем перехват на TxtEdtDoc::createView
            // он нужен только один раз, чтобы получить готовый объект TxtEdtView, т.к. создать его сейчас
            // самостоятельно ещё рано, программа вылетит.
            trTxtEdtDoc_createView.setTrap(&&doc, IDocument_createView, TxtDoc_createView);
            dbgLog("setTextHooks: trap doc.createView state=" + trTxtEdtDoc_createView.state + " слот=" + IDocument_createView);
        }
    } else if (trTxtEdtCtrl_createWnd.state == trapDisabled) {
        trTxtEdtCtrl_createWnd.swap();
        trTxtCtrCommand_onExecute.swap();
        trTxtMgr_setExtender.swap();
        if (trTxtEdtView_createWnd.state == trapDisabled)
            trTxtEdtView_createWnd.swap();
        else if (trTxtEdtView_createWnd.state == trapNotActive && trTxtEdtDoc_createView.state == trapDisabled)
            trTxtEdtDoc_createView.swap();
    }
    textDocStorage.enableTextWork();
    return true;
}

int_ptr TxtDoc_createView(IDocument& doc, int_ptr pView) {
    dbgLog("TxtDoc_createView вызван");
    trTxtEdtDoc_createView.swap();
    IUnknown&& unk;
    doc.createView(unk);
    IWindowView&& wnd = unk;

    if (wnd is null)
        Print("Не удалось создать TxtEdtView IWindowView");
    else {
        trTxtEdtView_createWnd.setTrap(&&wnd, IWindowView_createWindow, TxtEdtView_createWindow);
        ICommandTarget&& tgt = wnd.unk;
        if (tgt is null)
            Print("Не удалось получить ICommandTarget из TxtEdtWnd IWindowView");
        else // Ставим перехват на получение окном текстового контрола команды
            trTxtEdtCommand_onExecute.setTrap(&&tgt, ICommandTarget_onExecute, TxtEdtCommand_onExecute);
    }
    if (unk !is null)
        unk.AddRef();
    mem::int_ptr[pView] = mem::addressOf(unk);
    return pView;
}

TrapVirtualStdCall trTxtEdtDoc_createView;
TrapVirtualStdCall trTxtEdtView_createWnd;
TrapVirtualStdCall trTxtEdtCtrl_createWnd;
TrapVirtualStdCall trTxtEdtCommand_onExecute;
TrapVirtualStdCall trTxtCtrCommand_onExecute;
TrapVirtualStdCall trTxtMgr_setExtender;

void disableAllTextTraps() {
    if (trTxtEdtDoc_createView.state == trapEnabled)
        trTxtEdtDoc_createView.swap();
    if (trTxtEdtView_createWnd.state == trapEnabled)
        trTxtEdtView_createWnd.swap();
    if (trTxtEdtCtrl_createWnd.state == trapEnabled)
        trTxtEdtCtrl_createWnd.swap();
    if (trTxtEdtCommand_onExecute.state == trapEnabled)
        trTxtEdtCommand_onExecute.swap();
    if (trTxtCtrCommand_onExecute.state == trapEnabled)
        trTxtCtrCommand_onExecute.swap();
    if (trTxtMgr_setExtender.state == trapEnabled)
        trTxtMgr_setExtender.swap();
}

funcdef bool WV_CreateWindow(IWindowView&, HWND parentWindow);
bool TxtEdtCtrl_createWindow(IWindowView& view, HWND parentWindow) {
#if test = 1
    dumpVtable(&&view, "_TxtEdtCtrl_createWindow");
#endif
    WV_CreateWindow&& orig;
    trTxtEdtCtrl_createWnd.getOriginal(&&orig);
    // «до» без «после» в журнале — падение внутри платформенного создания окна (разбор 2026-10-03: frntend.dll+0x7f4adf)
    diagAlways("win", "TxtEdtCtrl.createWindow: до оригинала, view=" + dbgHex(view.self) + " parent=" + dbgHex(parentWindow) + (diagCtx.isEmpty() ? "" : " контекст: " + diagCtx));
    bool res = orig(view, parentWindow);
    diagAlways("win", "TxtEdtCtrl.createWindow: оригинал вернул " + res);
    onCreateTextWnd(view, true, parentWindow);
    return res;
}

bool TxtEdtView_createWindow(IWindowView& view, HWND parentWindow) {
    dbgLog("TxtEdtView_createWindow вызван");
#if test = 1
    dumpVtable(&&view, "_TxtEdtView_createWindow");
#endif
    WV_CreateWindow&& orig;
    trTxtEdtView_createWnd.getOriginal(&&orig);
    diagAlways("win", "TxtEdtView.createWindow: до оригинала, view=" + dbgHex(view.self) + " parent=" + dbgHex(parentWindow) + (diagCtx.isEmpty() ? "" : " контекст: " + diagCtx));
    bool res = orig(view, parentWindow);
    diagAlways("win", "TxtEdtView.createWindow: оригинал вернул " + res);
    onCreateTextWnd(view, false, parentWindow);
    return res;
}

bool TxtEdtCommand_onExecute(ICommandTarget& tgt, const Command& command) {
#if test = 1
    dumpVtable(&&tgt, "_TxtEdtCommand_onExecute");
#endif
    return checkCommandAndHideSmartBox(tgt, command, trTxtEdtCommand_onExecute);
}

bool TxtCtrCommand_onExecute(ICommandTarget& tgt, const Command& command) {
#if test = 1
    dumpVtable(&&tgt, "_TxtCtrCommand_onExecute");
#endif
    return checkCommandAndHideSmartBox(tgt, command, trTxtCtrCommand_onExecute);
}

int TxtMgrOper_setExtender(ITextManager_Operations& to, const Guid& clsid) {
#if test = 1
    dumpVtable(&&to, "_TxtMgrOper_setExtender");
#endif
    trTxtMgr_setExtender.swap();
    int res = to.setExtenderCLSID(clsid);
    trTxtMgr_setExtender.swap();
    ITextManager&& itm = to.unk;
    changeTextExtender(itm, clsid);
    return res;
}
