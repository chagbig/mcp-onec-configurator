﻿/*
 * Автоподключение файла шаблонов текста 1С, поставляемого со Снегопатом (x64/templates/ТсРазработкаШаблоны1с8.st).
 * При запуске Конфигуратора: если в папке templates Снегопата есть файлы *.st, список файлов шаблонов 1С (профиль 1С, раздел TxtEdt,
 * ключ AutoPlacementFilesRU1) заменяется ровно ими: чужие записи, в том числе наш файл по старому пути после переноса папки, удаляются.
 * Ни одного *.st в папке (или папки нет): список и настройки 1С не трогаем.
 * Одновременно с подключением (один раз, пока файла в списке нет — дальше настройки остаются за пользователем):
 *   - отключаются стандартные шаблоны платформы (Настройка шаблонов → «Использовать стандартные шаблоны»: TxtEdt/AutoSearchTemplateFiles=Ложь);
 *   - Сервис → Параметры → Модули → Редактировать → «Автозамена» = «Включить с подсказкой» (ModuleTextEditor/AutoPlacement=2:
 *     0 «Отключить», 1 «Включить», 2 «Включить с подсказкой», 3 «Только подсказка»).
 */
#pragma once
#include "../all.h"

const string tplFileName = "ТсРазработкаШаблоны1с8.st";
const string tplProfileKeyDefault = "TxtEdt/AutoPlacementFilesRU1";

Packet pktTemplates("RegisterTemplates", registerTemplateFile, piOnMainEnter);

// Корень Снегопата (на два уровня выше папки модуля: <корень>\modules\snegopat\) с прямыми слэшами и без завершающего
string tplRootDir() {
    string s = myFolder;
    s.replace("\\", "/");
    for (int k = 0; k < 2; k++) {
        while (s.length > 0 && s[s.length - 1] == '/')
            s.setLength(s.length - 1);
        while (s.length > 0 && s[s.length - 1] != '/')
            s.setLength(s.length - 1);
    }
    while (s.length > 0 && s[s.length - 1] == '/')
        s.setLength(s.length - 1);
    return s;
}

// Записать значение в профиль платформы (нет ключа — создать в базовом хранилище, как для списка файлов шаблонов)
void tplSetPlatformValue(IProfileFolder&& pf, const string& key, const Value& val) {
    if (!pf.setValue(key, val))
        pf.createAndSetValue(key, gpflBase, val);
}

// Настройки, которые выставляются вместе с подключением нашего файла шаблонов
void tplApplyPlatformOptions(IProfileFolder&& pf) {
    Value noStd;
    noStd = false;
    tplSetPlatformValue(pf, "TxtEdt/AutoSearchTemplateFiles", noStd);
    Value autoRepl;
    autoRepl = 2;
    tplSetPlatformValue(pf, "ModuleTextEditor/AutoPlacement", autoRepl);
    diagAlways("templates", "стандартные шаблоны отключены, Автозамена = «Включить с подсказкой»");
}

bool registerTemplateFile() {
    string root = tplRootDir();
    // Ни одного *.st в папке templates Снегопата (или папки нет): шаблоны 1С не трогаем
    array<string> names = diagListDir(root + "/templates/*.st", false);
    if (names.length == 0) {
        diag("templates", "в папке нет файлов *.st, шаблоны 1С не трогаем: " + root + "/templates");
        return true;
    }
    // для проверки без вмешательства в рабочие настройки: logs/diag.ini «templates.key=TxtEdt/AutoPlacementFilesRU9»
    diagReload();
    string tplProfileKey = diagGet("templates.key");
    if (tplProfileKey.isEmpty())
        tplProfileKey = tplProfileKeyDefault;
    IProfileFolder&& pf = getProfileService();
    v8string cur;
    pf.getString(tplProfileKey, cur);
    string text = cur;
    string low = diagLower(text);
    // Список файлов шаблонов 1С = ровно файлы *.st из папки templates Снегопата; чужие записи (в том числе наш файл по старому пути
    // после переноса папки) убираются. Решение владельца 2026-11-07.
    names.sortAsc();
    string res = "{" + names.length + ",";
    for (uint k = 0; k < names.length; k++)
        res += (k == 0 ? "
" : ",
") + "{\"file://" + root + "/templates/" + names[k] + "\",0}";
    res += "
}";
    string norm = diagLower(text.trim(" 
	"));
    if (norm == diagLower(res)) {
        diagAlways("templates", "список файлов шаблонов 1С уже совпадает с папкой Снегопата: " + names.length + " файл(ов)");
        return true;
    }
    // «{N,» — число записей до замены (для журнала)
    uint n = 0;
    uint i = 1;
    string t = text.trim(" 
	");
    while (t.length > i && t[i] >= '0' && t[i] <= '9') {
        n = n * 10 + (t[i] - '0');
        i++;
    }
    bool ourFile = diagFileExists(root + "/templates/" + tplFileName);
    // настройки платформы ставим только при первом подключении нашего файла (если он в папке есть)
    bool firstTime = ourFile && low.find(diagLower(tplFileName)) == badStrIdx;
    bool ok = pf.setValue(tplProfileKey, Value(v8string(res)));
    if (!ok)
        pf.createAndSetValue(tplProfileKey, gpflBase, Value(v8string(res)));
    // flush и уведомление об изменении настроек здесь не вызываем: на старте (piOnMainEnter) это подвешивало загрузку Конфигуратора;
    // значение попадает в профиль 1С и сохраняется платформой при выходе, шаблоны подхватываются при ближайшем чтении настроек
    diagAlways("templates", "список файлов шаблонов 1С заменён папкой Снегопата: " + root + "/templates, файлов " + names.length + " (было записей: " + n + ")");
    if (firstTime && diagGet("templates.key").isEmpty())     // в режиме проверки (templates.key=…) рабочие настройки не трогаем
        tplApplyPlatformOptions(pf);
    return true;
}
