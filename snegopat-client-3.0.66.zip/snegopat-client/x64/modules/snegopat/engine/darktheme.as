// Palette selection uses Snegopat's file settings and the native renderer.
#pragma once
#include "../all.h"

string colorPalette = "standard";
string customPaletteColors = "";
string displayedColorPalette = "standard";
OptionsEntry oePaletteColors("PaletteColors", function(v){v = "";},
    function(v){v8string text; v.getString(text); customPaletteColors = text;},
    function(v){v8string text; v.getString(text); customPaletteColors = text; applyColorPalette(); return false;});
void defaultColorPalette(Value& value) {
    Value oldValue;
    bool oldEnabled = false;
    if (optionRead("Snegopat/Settings/DarkTheme", oldValue))
        oldValue.getBoolean(oldEnabled);
    value = oldEnabled ? "ristretto" : "standard";
}
void readColorPalette(const Value& value) {
    v8string text;
    value.getString(text);
    colorPalette = text;
    if (colorPalette != "ristretto" && colorPalette != "darkmodern" && colorPalette.find("custom:") != 0)
        colorPalette = "standard";
}
OptionsEntry oeColorPalette("ColorPalette", &&defaultColorPalette,
    function(v){readColorPalette(v);},
    function(v){readColorPalette(v); applyColorPalette(); return false;});
Packet colorPalettePacket("ColorPalette", initColorPalette, piOnMainEnter);

void applyColorPalette() {
    renderColorPalette(colorPalette, customPaletteColors);
}
void renderColorPalette(const string& selectedPalette, const string& paletteColors) {
    displayedColorPalette = selectedPalette;
  #if x86 = 0
    if (selectedPalette.find("custom:") == 0) {
        array<string>&& parts = paletteColors.split(";");
        bool valid = parts.length == 16;
        if (valid) {
            for (uint i = 0; i < 15; i++)
                if (nativeThemeColor(i, parts[i+1].parseInt()) == 0)
                    valid = false;
        }
        if (valid && nativeThemeCustom(parts[0].parseInt()) != 0)
            return;
        nativeSelectPalette(0);
        doLog("Invalid custom palette; standard appearance restored");
        return;
    }
    int index = selectedPalette == "ristretto" ? 1 : (selectedPalette == "darkmodern" ? 2 : 0);
    if (nativeSelectPalette(index) == 0)
        doLog("Palette renderer initialization failed");
  #endif
}
bool initColorPalette() {
  #if x86 = 0
    if (colorPalette != "standard")
        applyColorPalette();
    idleHandlers.insertLast(function(){
        if (displayedColorPalette != "standard")
            nativeThemeRefresh();
    });
  #endif
    return true;
}
