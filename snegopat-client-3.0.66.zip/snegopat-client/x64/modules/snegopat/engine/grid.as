﻿/*
 * (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
 * Работа с табличным полем
 */

// Данные строки нужны только для среды разработки и вырезаются препроцессором
#pragma once
#include "../all.h"

enum DataSourceType {
    dstGrid = 0,
    dstTree = 1
};


class IDataRow {
    IDataSource&& _owner;
    IV8Bookmark&& bkmk;
    IDataRow(IDataSource&& pOwner, IV8Bookmark&& pBkmk) {
        &&_owner = pOwner;
        &&bkmk = pBkmk;
    }
    IDataRow&& _getRow(LinkType lt) {
        IV8Bookmark&& b;
        _owner.m_ds.getLinkedBookmark(b, bkmk, lt);
        if (b is null)
            return null;
        return IDataRow(_owner, b);
    }

    IDataRow&& get_parent() {
        return _getRow(ltParent);
    }
    IDataRow&& get_firstChild() {
        return _getRow(ltFirstChild);
    }
    IDataRow&& get_lastChild() {
        return _getRow(ltLastChild);
    }
    IDataRow&& get_next() {
        return _getRow(ltNext);
    }
    IDataRow&& get_prev() {
        return _getRow(ltPrev);
    }
    Variant getCellValue(int columnID) {
        Value val;
        _owner.m_ds.getCellValue(bkmk, columnID, val);
        Variant ret;
        val2var(val, ret);
        return ret;
    }
    ICellAppearance&& getCellAppearance(long columnID) {
        if (_owner.m_ui !is null) {
            ICellAppearance pCA;
            pCA.cell.init();
            _owner.m_ui.getCellFormat(bkmk, columnID, pCA.m_value, pCA.cell);
            return pCA;
        }
        return null;
    }
};

class IDataSource {
    IV8DataSource&& m_ds;
    IGridUISource&& m_ui;
    IDataRow&& _root;
    IDataSource(IV8DataSource& pDS, IGridUISource& pUI) {
        &&m_ds = pDS;
        &&m_ui = m_ds.unk;
        if (m_ui is null)
            &&m_ui = pUI;
        &&_root = IDataRow(this, null);
    }
    DataSourceType get_type() {
        return DataSourceType(m_ds.getSourceType());
    }
    bool get_hasCellAppearance() {
        return m_ui !is null;
    }
};

class ICellAppearance  {
    CellFormat cell;
    Value m_value;
    string get_text() {
        return cell.text.str;
    }
    int get_checked() {
        return cell.state;
    }
    Variant get_picture() {
        return image2pict(toIUnknown(cell.image.image));
    }
    Variant get_addPicture() {
        return image2pict(toIUnknown(cell.extImage.image));
    }
    Variant get_value() {
        Variant ret;
        val2var(m_value, ret);
        return ret;
    }
};

class IGridCtrl : IExtControl {
    IDataSource&& _dataSource;
    IGrid&& grd;
    
    IGridCtrl(IGrid&& pGrid) {
        &&grd = pGrid;
        if (grd !is null) {
            IV8DataSource&& ds = grd.getDataSource();
            if (ds !is null) {
                &&_dataSource = IDataSource(ds, grd.getUISource());
            }
        }
    }

    // корень строк, чтобы обходить таблицу/дерево без текущей строки
    IDataRow&& get_rootRow() {
        return _dataSource is null ? null : _dataSource._root;
    }
    int get_columnCount() {
        return grd.columnsCount();
    }
    IDataRow&& get_currentRow() {
        IV8Bookmark&& line;
        grd.getCurrentLine(line);
        if (line !is null)
            return IDataRow(_dataSource, line);
        return null;
    }
    void set_currentRow(IDataRow&& val) {
        if (val is null || val._owner !is _dataSource)
            return;
        int colId = grd.getCurrentColumnId();
        grd.setActiveCell(val.bkmk, colId, true, eCenter, 0, 0);
    }
    int get_currentColID() {
        return grd.getCurrentColumnId();
    }
    void set_currentColID(int val) {
        grd.setCurrentColumnId(val);
    }
    bool isExpanded(IDataRow&& row) {
        if (row is null || row._owner !is _dataSource)
            return false;
        return grd.isExpandedLine(row.bkmk);
    }
    void expand(IDataRow&& row, bool bExpand, bool withChilds = false) {
        if (row is null || row._owner !is _dataSource)
            return;
        grd.expandLine(row.bkmk, bExpand, withChilds);
    }
    // Пометка строк дерева метаданных (engine/mark_paint.as): paths, по одному пути через «/» в строке; prefix добавляется к тексту помеченной строки
    void paintMarks(const string& paths, const string& prefix) {
        if (grd is null)
            return;
        IGridUISource&& ui = grd.getUISource();
        if (ui is null)
            return;
        markPaintSetup(ui, paths, prefix);
    }
    // Снять или вернуть перехват текста помеченных строк (engine/mark_paint.as)
    void paintActive(bool on) {
        markPaintActive(on);
    }
    // Диагностика ABI (сверка слотов IGrid между платформами, research/): адрес объекта, адрес таблицы методов, база нескольких модулей и первые n слотов
    string vtableInfo(uint n) {
        if (grd is null)
            return "нет";
        int_ptr obj = grd.self;
        int_ptr vt = mem::int_ptr[obj];
        string r = "obj=" + formatInt(obj, "0x", 16) + " vt=" + formatInt(vt, "0x", 16);
        string m1 = "frntend.dll", m2 = "frame.dll", m3 = "basic.dll", m4 = "basicui.dll", m5 = "backend.dll", m6 = "config.dll", m7 = "core83.dll", m8 = "core85.dll";
        r += " frntend=" + formatInt(GetModuleHandle(m1.cstr), "0x", 16) + " frame=" + formatInt(GetModuleHandle(m2.cstr), "0x", 16)
            + " basic=" + formatInt(GetModuleHandle(m3.cstr), "0x", 16) + " basicui=" + formatInt(GetModuleHandle(m4.cstr), "0x", 16)
            + " backend=" + formatInt(GetModuleHandle(m5.cstr), "0x", 16) + " config=" + formatInt(GetModuleHandle(m6.cstr), "0x", 16)
            + " core83=" + formatInt(GetModuleHandle(m7.cstr), "0x", 16) + " core85=" + formatInt(GetModuleHandle(m8.cstr), "0x", 16);
        r += " slots:";
        for (uint i = 0; i < n; i++)
            r += " " + formatInt(mem::int_ptr[vt + i * sizeof_ptr], "0x", 16);
        return r;
    }
    int isCellChecked(IDataRow&& row, int columnID) {
        if (row is null || row._owner !is _dataSource)
            return 0;
        return grd.getCellCheck(row.bkmk, columnID);
    }
    void checkCell(IDataRow&& row, int columnID, CheckState mark = 0) {
        if (row is null || row._owner !is _dataSource)
            return;
        grd.setCellCheck(row.bkmk, columnID, mark);
    }
};
