﻿/*
 * (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
 * Загрузчик скриптов
 */

// Данные строки нужны только для среды разработки и вырезаются препроцессором
#pragma once
#include "../all.h"

Packet ScriptInit("ScriptInit", initScripts, piOnMainWindow);

bool initScripts() {
    string nameOfInstance = getDefaultInfoBase().connectString();
    // Получим хэндл основного окна
    IWindow&& win = mainFrame.unk;
    hRealMainWnd = win.hwnd();
    initActiveScriptSubsystem(hRealMainWnd, nameOfInstance);
    return true;
}

// Аддин - скрипт
class AddinScript : Addin, ScriptSite {
    protected ActiveScript script;
    protected SelfScript selfScript;
    private uint errorsCount = 0;
    AddinScript(const string& u, const string& d, const string& f) {
        uName = u;
        dName = d;
        fPath = "script:" + f;
        selfScript._fullPath = f;
    }
    void _connectSelf() {
        &&selfScript.__addin = this;
        // Подключим объект, возвращающий все объявленные в AngelScript значения перечислений
        script.addNamedItem("Enums", getEnumsDispatch(), !(jsEngineMajor >= 11 && jsShimEnabled()));
        // Подключим корень SnegAPI
        // JScript 11: любой элемент-глобальные члены хоста (SCRIPTITEM_GLOBALMEMBERS) запрещает создавать неявные глобальные переменные
        // и свойства (x = 1, self[имя] = ...), поэтому Designer и Enums подключаются обычными элементами, а их имена без префикса
        // объявляет обёртка из jscript_shim.as. jsEngineMajor становится известен после старта первого скрипта (std/main.js)
        script.addNamedItem("Designer", oneDesigner._me(), !(jsEngineMajor >= 11 && jsShimEnabled()));
        // Подключим сам скрипт, для рефлексии
        script.addNamedItem("SelfScript", createDispatchFromAS(&&selfScript), false);
    }
    ActiveScript&& _script() { return script;  }
    // получить массив имен макросов
    array<string>&& macroses() {
        return script.extractMacroses();
    }
    // выполнить макрос
    Variant invokeMacros(const string& macros) {
        Variant result;
        script.invokeMacros(macros, result);
        return result;
    }
    // получить Dispatch объект
    IUnknown&& object() {
        dbgLog("js: getObject '" + uName + "'");
        return script.getObject();
    }
    // Вызывается из snegopat.dll при ошибке в скрипте
    bool onScriptError(const ScriptError& err) {
        errorsCount++;
        dbgLog("Ошибка скрипта " + uName + ": " + err.description + " (строка " + err.line + ", колонка " + err.col + ", " + err.source + ", " + fPath + ")");
        if (errorsCount > 5) {
            Message("Скрипт " + uName + " совершил пять ошибок и будет прерван", mInfo);
            script.abort();
            return false;
        }
        // ошибка — в окно сообщений, а не модальным окном: модальное блокирует Конфигуратор
        // и внешнее управление им. Отладчик скриптов из-за этого не предлагается.
        // Message() прямо из обработчика ошибки роняет процесс (8.3.27) — текст уходит в очередь, её забирает addins/std/errorlog.js
        // по таймеру (Designer.takeScriptError), выводит в окно сообщений и дописывает в logs\script-errors.txt.
        scriptErrorQueue.insertLast("Ошибка выполнения скрипта " + uName + ": " + err.description +
            " (строка " + err.line + ", колонка " + err.col + ", " + err.source + ", " + fPath + ")");
        return false;
    }
    // Вызывается из snegopat.dll при входе в выполнение скрипта
    void enter() {
        oneAddinMgr.enterInAddinRun(this);
    }
    // Вызывается из snegopat.dll при выходе из выполнения скрипта
    void leave() {
        oneAddinMgr.leaveAddinRun(this);
    }

    void _unload() {
        &&selfScript.__addin = null;
        script.stop();
        uName.makeEmpty();
    }
};

// Тексты ошибок скриптов, ожидающие вывода (см. AddinScript::onScriptError)
array<string> scriptErrorQueue;

class SelfScript {
    AddinScript&& __addin;
    string get_uniqueName()     { return __addin is null ? string() : __addin.uniqueName; }
    string get_displayName()    { return __addin is null ? string() : __addin.displayName; }
    string _fullPath;
    IUnknown&& get_self()       { return __addin is null ? null : __addin.object(); }
    void addNamedItem(const string& name, IDispatch&& unk, bool global = false) {
        if (__addin !is null)
            __addin._script().addNamedItem(name, unk, global);
    }
};

// Обход для JScript 11 (jscript_shim.as). diag.ini: js.shim=off выключает подстановку;
// js.engine=chakra запускает JScript-скрипты на движке JScript9Legacy даже на старой Windows (проверка обхода без подмены системы)
bool jsShimEnabled() {
    diagReload();
    return diagGet("js.shim") != "off";
}

string jsEngineName(const string& engine) {
    diagReload();
    if (engine == "JScript" && diagGet("js.engine") == "chakra")
        return "{16d51579-a30b-4c8b-a276-0ff4dc41e755}";
    return engine;
}

bool jsIdentChar(uint c) {
    return (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 95 || c == 36 || c > 127;
}

// Мажорная версия JScript, о которой сообщил стартовый скрипт (Designer.jsEngineVersion из jscript_shim.as); 0 — ещё не известна
uint jsEngineMajor = 0;

// JScript 11: если первый исполняемый оператор файла — присваивание в начале строки (TypeScript: exports.__esModule = true), движок повторно
// исполняет верх скрипта (stdlib: require уже заменён и бросает «Не найден скрипт»); любой оператор перед ним в той же строке это снимает.
// Причина не выяснена, приём проверен пробами (research/jscript9legacy-analysis-2026-10-28.md). Ставим «;» перед первым оператором,
// пропуская пробелы и комментарии.
string jsMarkFirstStatement(const string& src) {
    uint i = 0, n = src.length;
    while (i < n) {
        uint c = src[i];
        if (c == 32 || c == 9 || c == 10 || c == 13) {
            i++;
        } else if (c == 47 && i + 1 < n && src[i + 1] == 47) {          // комментарий до конца строки
            while (i < n && src[i] != 10 && src[i] != 13)
                i++;
        } else if (c == 47 && i + 1 < n && src[i + 1] == 42) {          // блочный комментарий
            i += 2;
            while (i + 1 < n && !(src[i] == 42 && src[i + 1] == 47))
                i++;
            i += 2;
        } else
            break;
    }
    if (i >= n)
        return src;
    // substr(0, 0) в Core.As возвращает всю строку, а не пустую
    if (i == 0)
        return ";" + src;
    return src.substr(0, i) + ";" + src.substr(i);
}

// Загрузчик скриптов
class ScriptLoader : AddinLoader {
    NoCaseMap<string> mapEngineNames;
    ScriptLoader() {
        super();
        mapEngineNames.insert("js", "JScript");
        mapEngineNames.insert("vbs", "VBScript");
    }
    string proto()                  { return "script"; }
    bool canUnload(Addin&& addin)   { return true; }
    Addin&& load(const string& uri) {
        string fullPath = findFullPath(uri);

        if (fullPath.isEmpty()) {
            oneAddinMgr._lastAddinError = "Не удалось найти файл " + uri;
            return null;
        }
        string source;
        readTextFile(source, fullPath);

        if (source.isEmpty()) {
            oneAddinMgr._lastAddinError = "Не удалось получить текст файла " + fullPath;
            return null;
        }
        array<array<string>&&> tags;
        uint firstLine = 0;
        extractTags(tags, source, firstLine);
        // Теперь надо получить уникальное имя и т.п.
        string uName = fullPath.extract(extractFileNameRex), dName, engine;
        array<array<any>&&> connectedAddins;
        bool attachDebuger = true;

        for (uint it = 0; it < tags.length; it++) {
            string tag = tags[it][0], val = tags[it][1];

            if (tag == "engine")
                engine = val;
            else if (tag == "uname")
                uName = val;
            else if (tag == "dname")
                dName = val;
            else if (tag == "nodebug" || (tag == "debug" && val == "no"))
                attachDebuger = false;
            else if (tag == "addin") {
                array<string>&& tail = val.split(whiteSpaceRex);
                if (tail.length > 0) {
                    Addin&& a = oneAddinMgr.byUniqueName(tail[0]);
                    if (a !is null) {
                        IUnknown&& obj = a.object();
                        if (obj !is null) {
                            connectedAddins.insertLast(array<any> = {
                                any(&&obj),
                                any(tail.length > 1 ? tail[1] : tail[0]),
                                any(tail.length > 2 ? (tail[2] == "global") : false)
                            });
                        } else {
                            oneAddinMgr._lastAddinError = "Аддин " + tail[0] + " не содержит объекта";
                            return null;
                        }
                    } else {
                        oneAddinMgr._lastAddinError = "Аддин " + tail[0] + " не найден";
                        return null;
                    }
                }
            }
        }
        if (engine.isEmpty()) {
            string fileExt = fullPath.match(extractFileExtRex).text(0, 0);
            auto fnd = mapEngineNames.find(fileExt);
            if (fnd.isEnd()) {
                engine = getEngineNameByFileExt(fileExt);
                if (!engine.isEmpty())
                    mapEngineNames.insert(fileExt, engine);
            } else
                engine = fnd.value;
            if (engine.isEmpty()) {
                oneAddinMgr._lastAddinError = "Не удалось получить имя скриптового движка для скрипта " + fullPath;
                return null;
            }
        }
        if (dName.isEmpty())
            dName = uName;
        AddinScript ads(uName, dName, fullPath);
        &&ads.__loader = this;
        ActiveScript&& script = ads._script();
        bool isJScript = engine == "JScript";
        // JScript 11: менеджеры глобальных контекстов (Метаданные и др.) объявляются кодом после connectGlobals, а не именованными элементами
        if (isJScript && jsEngineMajor >= 11 && jsShimEnabled())
            source.replace("connectGlobals(SelfScript)", "connectGlobals(SelfScript);" + jsGcMgrCode);
        if (isJScript && jsEngineMajor >= 11 && jsShimEnabled()) {
            string marked = jsMarkFirstStatement(source);
            if (diagTraceOn("js"))
                dbgLog("js: метка первого оператора '" + uName + "': было [" + source.substr(0, 24) + "] стало [" + marked.substr(0, 24) + "] длины " + source.length + "/" + marked.length);
            source = marked;
        }
        if (engine == "JScript" && firstLine > 0) {
            source.replace("(this && this.__extends) ||", "");
            // Функцию require добавляем как переменную, потому что в stdlib она потом меняется на другую реализацию
            source.insert(0, "var exports=SelfScript.self;var require=function(s){return builtin_require(s);};\n");
            firstLine--;
        }
        // JScript 11 (Windows 11 24H2, Server 2025): имена из глобальных членов Designer не разрешаются, см. jscript_shim.as.
        // Подстановка на той же строке: номера строк в сообщениях об ошибках не сдвигаются
        if (isJScript && jsShimEnabled())
            source.insert(0, jsChakraShim);
        if (isJScript && diagTraceOn("js") && jsEngineMajor >= 11) {
            dbgLog("js: начало исходника '" + uName + "' (" + source.length + "): " + source.substr(0, 260));
            uint from = jsShimEnabled() ? jsChakraShim.length : 0;
            dbgLog("js: итоговое начало '" + uName + "': " + source.substr(from, 700).replace("\n", "<LF>").replace("\r", "<CR>"));
        }
        if (script.prepare(jsEngineName(engine), source, firstLine, uName, /*attachDebuger*/true, ads) != 0)
            return null;
        ads._connectSelf();
        // Подключим аддины, которые скрипт просил
        for (uint k = 0, km = connectedAddins.length; k < km; k++) {
            array<any>&& a = connectedAddins[k];
            IUnknown&& obj;
            string name;
            bool global;
            a[0].retrieve(&&obj);
            a[1].retrieve(name);
            a[2].retrieve(global);
            script.addNamedItem(name, obj, global);
        }
        return ads;
    }
    bool run(Addin&& addin) {
        dbgLog("js: run '" + addin.uniqueName + "'");
        uint res = cast<AddinScript>(addin)._script().run();
        dbgLog("js: run '" + addin.uniqueName + "' завершён");
        if (res > 0) {
            Message("не удалось запустить скрипт " + addin.uniqueName);
            oneAddinMgr._lastAddinError = "Не удалось запустить скрипт " + addin.uniqueName + " из " + addin.fullPath;
            return false;
        }
        return true;
    }
    bool unload(Addin&& addin) {
        cast<AddinScript>(addin)._unload();
        if (!unloadIdleHandlerSet) {
            idleHandlers.insertLast(unloadDelayedScripts);
            unloadIdleHandlerSet = true;
        }
        return true;
    }
    string nameOfLoadCommand() { return "Загрузить скрипт|script"; }
    string selectLoadURI() {
        // Сделаем всё штатным 1Сным диалогом выбора файла
        IContext&& selModes = oneDesigner._createValue("ПеречислениеРежимДиалогаВыбораФайла");
        ValueParamsVector args(1);
        selModes.getPropVal(selModes.staticContextDef().findProp("Открытие"), args.values[0]);
        IContext&& selDlg = oneDesigner._createValue("ДиалогВыбораФайла", args);
        IContextDef&& def = selDlg.staticContextDef();
        selDlg.setPropVal(def.findProp("Заголовок"), Value("Выберите файл скрипта"));
        selDlg.setPropVal(def.findProp("ПредварительныйПросмотр"), Value(false));
        selDlg.setPropVal(def.findProp("Фильтр"), Value("Файлы скриптов (*.js;*.vbs)|*.js;*.vbs|Все файлы|*"));
        Value retVal;
        selDlg.callMeth(def.findMethod("Выбрать"), retVal, Vector());
        bool res = false;
        if (retVal.getBoolean(res) && res) {
            selDlg.getPropVal(def.findProp("ПолноеИмяФайла"), retVal);
            v8string path;
            retVal.getString(path);
            return "script:" + path;
        }
        return string();
    }
};
ScriptLoader oneScriptLoader;
bool unloadIdleHandlerSet = false;

void extractTags(array<array<string>&&>& tags, string& sources, uint& firstLineIdx) {
    uint startPos = 0;
    if (sources.length > 13 && sources.substr(0, 14) == "\"use strict\";\n")
        startPos = 14;
    for (;;) {
        auto match = scriptTagsRex.match(sources, 1, startPos);
        if (match.matches == 0 || match.begin(0, 0) != startPos)
            break;
        firstLineIdx++;
        string key = match.text(0, 1);
        if (key.isEmpty())
            key = match.text(0, 2);
        tags.insertLast(array<string> = { key, match.text(0, 3) });
        startPos += match.len(0, 0);
    }
    if (startPos > 0)
        sources.remove(0, startPos);
}
