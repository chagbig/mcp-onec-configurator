﻿// Пометка строк дерева метаданных (аддин mdMarks): перехват IGridUISource::getCellFormat источника дерева конфигурации.
// Платформа вызывает его при построении строк (раскрытие ветки) и берёт из результата текст и картинку, поэтому цвет фона так не поменять,
// а текст можно: у помеченной строки к тексту добавляется префикс. Строка помечена, если её полный путь из имён (корень конфигурации/вид/объект)
// есть в множестве, переданном из аддина через IGridCtrl::paintMarks. Остальные строки и другие таблицы не затрагиваются.
// Параметр колонки объявлен int_ptr, а не uint: переходник отдаёт аргументы 8-байтовыми слотами, с uint остальные аргументы съезжают на 4 байта.
#pragma once
#include "../all.h"

TrapVirtualStdCall trMarkPaint;
funcdef bool MarkPaint_t(IGridUISource&, IV8Bookmark&, int_ptr, Value&, CellFormat&);

NoCaseSet markPaths;            // полные пути помеченных объектов
NoCaseSet markLeafNames;        // последние элементы путей: быстрый отсев строк без метки
uint markCount = 0;
string markPrefix = "";
array<int_ptr> markSources;     // адреса источников деревьев, для которых включена пометка (основная конфигурация и расширения: окон деревьев несколько; другие таблицы с тем же классом не трогаем)
int_ptr markTreeObject = 0;     // последний зарегистрированный источник (для журнала)

bool markIsSource(int_ptr self) {
    for (uint i = 0; i < markSources.length; i++)
        if (markSources[i] == self)
            return true;
    return false;
}
uint markLogLeft = 8;           // сколько первых событий записать в журнал (категория marks)

// Имя строки (колонка 0), для строк-предков. Свежая структура на каждый вызов и освобождение текста: 8.3.27 и 8.5 иначе падают (как в StockListInterceptor)
string markRowName(MarkPaint_t&& original, IGridUISource& src, IV8Bookmark& b) {
    CellFormat c;
    c.init();
    c.validFields = cfText;
    Value v;
    string s;
    if (original(src, b, 0, v, c))
        s = c.text;
    c.text = "";
    return s;
}

bool markPaintTrap(IGridUISource& src, IV8Bookmark& bkmk, int_ptr colIdRaw, Value& value, CellFormat& cf) {
    uint colId = uint(colIdRaw & 0xFFFFFFFF);
    MarkPaint_t&& original;
    trMarkPaint.getOriginal(&&original);
    bool res = original(src, bkmk, colId, value, cf);
    if (!res || markCount == 0 || colId != 0 || !markIsSource(src.self))
        return res;
    // Имя читаем отдельным вызовом: маска полей у платформы лежит не там, где её описывает CellFormat (на 8.3.24+ по +0x2C0), поэтому
    // validFields структуры платформы проверять нельзя
    string name = markRowName(original, src, bkmk);
    if (name.isEmpty() || !markLeafNames.contains(name))
        return res;
    IV8DataSource&& ds = cast<IUnknown>(src);
    if (ds is null)
        return res;
    string path = name;
    IV8Bookmark&& cur = bkmk;
    for (uint depth = 0; depth < 16; depth++) {
        IV8Bookmark&& parent;
        ds.getLinkedBookmark(&&parent, cur, ltParent);
        if (parent is null)
            break;
        path = markRowName(original, src, parent) + "/" + path;
        &&cur = parent;
    }
    if (markPaths.contains(path)) {
        if (markLogLeft > 0) {
            markLogLeft--;
            if (diagTraceOn("marks"))
                diagAlways("marks", "строка помечена: " + path);
        }
        cf.text = markPrefix + name;
    }
    return res;
}

// paths: пути через «/», по одному в строке; prefix: добавляется к тексту помеченной строки. Пустой список снимает пометки (перехват остаётся, но ничего не делает)
void markPaintSetup(IGridUISource& ui, const string& paths, const string& prefix) {
    markPaths.clear();
    markLeafNames.clear();
    markCount = 0;
    markPrefix = prefix;
    array<string>&& list = paths.split("\n");
    for (uint i = 0; i < list.length; i++) {
        string p = list[i];
        if (p.isEmpty())
            continue;
        markPaths.insert(p);
        array<string>&& parts = p.split("/");
        markLeafNames.insert(parts[parts.length - 1]);
        markCount++;
    }
    // Пути передаются целиком для всех деревьев сразу (в них первым элементом стоит имя корня, поэтому деревья не пересекаются), а источник
    // добавляется к уже известным: раньше второе дерево (расширение) вытесняло первое, и звёздочки в нём пропадали
    markTreeObject = ui.self;
    if (!markIsSource(markTreeObject)) {
        if (markSources.length >= 16)
            markSources.removeAt(0);
        markSources.insertLast(markTreeObject);
    }
    markLogLeft = 8;
    if (diagTraceOn("marks"))
        diagAlways("marks", "paintMarks: меток " + markCount + ", источник " + formatInt(markTreeObject, "0x", 16) + (trMarkPaint.state == trapNotActive ? ", ставлю перехват" : ", перехват уже стоит"));
    if (trMarkPaint.state == trapNotActive) {
        IGridUISource&& handle = ui;
        trMarkPaint.setTrap(&&handle, IGridUISource_getCellFormat, markPaintTrap);
    }
}

// Временно снимает перехват (в таблице методов оригинал) или возвращает его. Чтение строк из скрипта на 8.3.17 через перехват иногда
// падает (AV внутри переходника), поэтому аддин на время своих чтений перехват снимает, а возвращает для раскрытия веток и по окончании.
// Построение строк самой платформой (окно, раскрытие мышью) идёт с включённым перехватом
void markPaintActive(bool on) {
    if (trMarkPaint.state == trapNotActive)
        return;
    if (on && trMarkPaint.state == trapDisabled)
        trMarkPaint.swap();
    else if (!on && trMarkPaint.state == trapEnabled)
        trMarkPaint.swap();
}
