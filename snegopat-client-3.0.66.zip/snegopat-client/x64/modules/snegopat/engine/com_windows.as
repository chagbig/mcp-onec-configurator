﻿/*
 * (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
 * Работы из аддинов с окнами 1С.
 */

// Данные строки нужны только для среды разработки и вырезаются препроцессором
#pragma once
#include "../all.h"

IDispatch&& dspWindows;

// Реализация объекта windows. Пока частичная.
class IV8Windows {
    IV8Windows() {
        &&dspWindows = createDispatchFromAS(&&this);
        // Инициализируем перехваты (diag.ini: hook.wintraps=off отключает все три, для бисекции сбоев на новой платформе)
        if (diagHook("wintraps", true)) {
            setTrapOnChangeTitle();
            setTrapOnMsgBox();
            setTrapOnMessage();
        }
        // Оповещение «окно открыто» (windows.onViewOpened); diag.ini: hook.openview=off отключает перехват
        if (diagHook("openview", true))
            setTrapOnOpenView();
        // Оповещение «окно закрыто» (windows.onViewClosed); diag.ini: hook.closeview=off отключает перехват
        if (diagHook("closeview", true))
            setTrapOnCloseView();
        idleHandlers.insertLast(clearViewMap);
    }
    // Основное окно
    IV8View&& get_mainView() {
        return mdiView.parent;
    }
    // Контейнер MDI-окон
    IV8View&& get_mdiView() {
        return getViewWrapper(gMDIClientID);
    }
    // Текущий модальный режим
    ModalStates get_modalMode() {
        // Диалог «Методы модуля» для платформы не модален; аддины (textEditorExt и др.) по этому признаку не трогают модуль под ним.
        if (methodsDialog !is null && methodsDialog.opened)
            return msModal;
        return getBkEndUI().currentModalState();
    }
    // Заголовок основного окна
    string get_caption() {
        if (mainFrame !is null) {
            IWindow&& w = mainFrame.unk;
            if (w !is null) {
                HWND hWnd = w.hwnd();
                int len = GetWindowTextLength(hWnd);
                string res;
                GetWindowText(hWnd, res.setLength(len), len + 1);
                return res;
            }
        }
        return string();
    }
    void set_caption(const string& str) {
        if (mainFrame !is null) {
            IWindow&& wnd = mainFrame.unk;
            if (wnd !is null)
                SetWindowText(wnd.hwnd(), str.cstr);
        }
    }
    // Основная часть заголовка
    string get_mainTitle() {
        string res;
        if (mainFrame !is null)
            res = mainFrame.getTitle();
        return res;
    }
    void set_mainTitle(const string& str) {
        if (mainFrame !is null)
            mainFrame.setTitle(str);
    }
    // Дополнительная часть заголовка
    string get_additionalTitle() {
        string res;
        if (mainFrame !is null)
            res = mainFrame.getAdditionalTitle();
        return res;
    }
    void set_additionalTitle(const string& str) {
        if (mainFrame !is null)
            mainFrame.setAdditionalTitle(str);
    }
    // Видимость окна свойств
    bool get_propsVisible() {
        IPropertyService&& props = currentProcess().getService(IID_IPropertyService);
        return props.isPropWndVisible();
    }
    void set_propsVisible(bool bVisible) {
        IPropertyService&& props = currentProcess().getService(IID_IPropertyService);
        props.showPropWnd(bVisible);
    }
    //Активное отображение
    IV8View&& getActiveView() {
        return frameView(ActiveViewInCoreFrame);
    }
    // Отображение в фокусе
    IV8View&& getFocusedView() {
        return frameView(FocusedViewInCoreFrame);
    }
    // Данный метод позволяет получить текущий текст из поля ввода на форме,
    // не дожидаясь перехода фокуса из поля.
    // На вход надо подать ЭУ (Форма.ЭлементыФормы.ИмяКонтрола)
    string getInputFieldText(const Variant& ctrl) {
        v8string res;
        Value val;
        var2val(ctrl, val);
        if (val.pValue !is null) {
            IControlContext&& ctx = val.pValue.unk;
            if (ctx !is null) {
                IUnknown&& unk;
                ctx.getControl(unk, IID_IFldEdit);
                if (unk !is null) {
                    IDataControl&& dc = unk;
                    if (unk !is null) {
                        dc.getValue(val);
                        val.getString(res);
                    }
                }
            }
        }
        return res;
    }
};

IV8View&& frameView(uint offset) {
    ITopLevelFrameCore&& tlc = coreMainFrame.unk;
    //doLog("Offsets of active and focused view in toplevelframe: искать от 0x" + formatInt(tlc.self, "0x", sizeof_ptr * 2));
    //MsgBox("Offsets of active and focused view in toplevelframe: искать от 0x" + formatInt(tlc.self, "0x", sizeof_ptr * 2));
    int_ptr addrOfViewCont = mem::int_ptr[tlc.self + offset];
    if (addrOfViewCont > 0) {
        //doLog("ViewContextInView: искать от 0x" + formatInt(addrOfViewCont + ViewContextInView, "0x", sizeof_ptr * 2));
        //MsgBox("ViewContextInView: искать от 0x" + formatInt(addrOfViewCont + ViewContextInView, "0x", sizeof_ptr * 2));
        ViewContextRef&& pCont = toViewContext(addrOfViewCont + ViewContextInView);
        return getViewWrapper(pCont.ref.id);
    }
    return null;

}

enum ViewContainerType {
    vctNo = 0,
    vctTabbed = 1,
    vctTwoViewsHorz = 2,
    vctTwoViewsVert = 3,
    vctMdiContainer = 4,
    vctUnknown = 5
};


NoCaseMap<IV8View&&> viewWrappers;
IV8View&& getViewWrapper(const Guid& id) {
    string strId = id;
    auto find = viewWrappers.find(strId);
    if (!find.isEnd())
        return find.value;
    IV8View v(id);
    viewWrappers.insert(strId, &&v);
    return v;
}

void clearViewMap() {
    array<string> removed;
    for (auto it = viewWrappers.begin(); !it.isEnd(); it++) {
        if (!it.value.isAlive())
            removed.insertLast(it.key);
    }
    for (uint i = 0, im = removed.length; i < im; i++)
        viewWrappers.remove(removed[i]);
}

IMDObject&& getMdObjFromView(IFramedView&& view) {
    IDocumentView&& dv = view.unk;
    if (dv !is null) {
        IDocument&& doc;
        dv.document(doc);
        dbgLog("getMdObjFromView: doc " + (doc is null ? "null" : "ok"));
        if (doc !is null) {
            IConfigMngrUI&& ui = doc.unk;
            if (ui is null) {
                IConfigMngrUIOwner&& ow = doc.unk;
                if (ow !is null)
                    &&ui = ow.getUI();
            }
            dbgLog("getMdObjFromView: ui " + (ui is null ? "null" : "ok"));
            if (ui !is null)
                return ui.getMDCont();
            else {
                dbgLog("getMdObjFromView: configMode=" + doc.getConfigMode());
                if (doc.getConfigMode()) {
                    IConnectionPointContainer&& pCont = doc.unk;
                    if (pCont !is null) {
                        IUnknown&& pCP;
                        if (0 == pCont.FindConnectionPoint(IID_IDocumentSink, pCP) && pCP !is null) {
                            //doLog("Search DocSinks at " + formatInt(pCP.self, "0X", 2 * sizeof_ptr));
                            //MsgBox("Search DocSinks at " + formatInt(pCP.self, "0X", 2 * sizeof_ptr));
                            int_ptr pdata = mem::int_ptr[pCP.self + sizeof_ptr];
                            uint size = mem::dword[pCP.self + 2 * sizeof_ptr];
                            if (dbgOn()) {
                                string dd = "sink pCP=" + formatInt(pCP.self, "0x", 16) + " pdata=" + formatInt(pdata, "0x", 16) + " size=" + size;
                                for (uint q = 0; q < 8; q++)
                                    dd += " [" + q + "]=" + formatInt(mem::int_ptr[pCP.self + q * sizeof_ptr], "0x", 16);
                                dbgLog(dd);
                                if (pdata > 0x10000) {
                                    string d2 = "obj@pdata";
                                    for (uint q = 0; q < 14; q++)
                                        d2 += " [" + q + "]=" + formatInt(mem::int_ptr[pdata + q * sizeof_ptr], "0x", 16);
                                    dbgLog(d2);
                                }
                            }
                          #if (ver >= 8.3.27 & ver < 8.3.28) | (ver >= 8.5.1 & ver < 8.5.2)
                            // в 27 (и пробно в 8.5.1) точка подключения хранит единственный sink прямо по [pCP+8]
                            DocSinkRef&& pSink27 = toDocSink(pdata);
                            if (pSink27 !is null && pSink27.ref.refCount < 10) {
                                IMDEditHelper&& eh27 = pSink27.ref.editHelper;
                                if (eh27 !is null)
                                    return eh27.getMDObj();
                            }
                          #else
                            for (uint i = 0; i < size; i++) {
                                DocSinkRef&& pSink = toDocSink(mem::int_ptr[pdata + i * sizeof_ptr]);
                                if (pSink !is null && pSink.ref.refCount < 10) {
                                    IMDEditHelper&& eh = pSink.ref.editHelper;
                                    if (eh !is null)
                                        return eh.getMDObj();
                                }
                            }
                          #endif
                        }
                    }
                }
            }
        }
    } else {
        // Проверить на форму редактирования объекта метаданных
        IEventRecipient&& er = view.unk;
        ICommandTarget&& ct = view.unk;
        if (er !is null && ct !is null && er.self < view.self && ct.request(CommandID(cmdFrameGroup, cmdFindInTree))) {
            /*doLog("MetaDataObjInEventRecipientOffset: Искать смещение от 0x" + formatInt(er.self, "0x", sizeof_ptr * 2) +
                " до объекта с интерфейсом " + IID_IMDObject);
            MsgBox("MetaDataObjInEventRecipientOffset: Искать смещение от 0x" + formatInt(er.self, "0x", sizeof_ptr * 2) +
                " до объекта с интерфейсом " + IID_IMDObject);*/
            IMDObject&& obj = toIUnknown(mem::int_ptr[er.self + MetaDataObjInEventRecipientOffset]);
            obj.AddRef();
            return obj;
        }
    }
    return null;
}


Guid getMdPropIDFromView(IFramedView&& view) {
    IDocumentView&& dv = view.unk;
    if (dv !is null) {
        IDocument&& doc;
        dv.document(doc);
        if (doc.getConfigMode()) {
            IConnectionPointContainer&& pCont = doc.unk;
            if (pCont !is null) {
                IUnknown&& pCP;
                if (0 == pCont.FindConnectionPoint(IID_IDocumentSink, pCP) && pCP !is null) {
                    int_ptr pdata = mem::int_ptr[pCP.self + sizeof_ptr];
                    uint size = mem::dword[pCP.self + 2 * sizeof_ptr];
                  #if (ver >= 8.3.27 & ver < 8.3.28) | (ver >= 8.5.1 & ver < 8.5.2)
                    DocSinkRef&& pSink27 = toDocSink(pdata);
                    if (pSink27 !is null && pSink27.ref.refCount < 10) {
                        IMDEditHelper&& eh27 = pSink27.ref.editHelper;
                        if (eh27 !is null)
                            return pSink27.ref.propId;
                    }
                  #else
                    for (uint i = 0; i < size; i++) {
                        DocSinkRef&& pSink = toDocSink(mem::int_ptr[pdata + i * sizeof_ptr]);
                        if (pSink !is null && pSink.ref.refCount < 10) {
                            IMDEditHelper&& eh = pSink.ref.editHelper;
                            if (eh !is null)
                                return pSink.ref.propId;
                        }
                    }
                  #endif
                }
            }
        }
    }
    return IID_NULL;
}

// Реализация объекта представления окна.
class IV8View {
    Guid __id;
    IV8View(const Guid& i) {
        __id = i;
    }
    IFramedView&& _getView(bool throwComError = true) {
        IFramedView&& view;
        mainFrame.getView(view, __id);
        if (view is null && throwComError)
            setComException("Отображение уже не существует");
        return view;
    }
    bool isAlive() {
        return _getView(false) !is null;
    }
    // Диагностика (редактор форм): какие описанные интерфейсы поддерживает отображение и его адрес
    string probe() {
      #if ver >= 8.5
        // на 8.5 перебор интерфейсов (QueryInterface по списку GUID) роняет Конфигуратор; чужие объекты 8.5 так не опрашиваем: см. vtableInfo()
        return "probe() отключён на 8.5, используйте vtableInfo()";
      #else
        IFramedView&& v = _getView(false);
        if (v is null)
            return "нет";
        string r = dbgHex(v.self) + " " + probeIfaces(v.unk);
        IDocumentView&& dv = v.unk;
        if (dv !is null) {
            IDocument&& doc;
            dv.document(doc);
            if (doc !is null) {
                r += "\n" + "  документ " + dbgHex(doc.self) + " " + probeIfaces(doc.unk);
                dbgDumpVT(doc.self, 41);
            }
        }
        return r;
      #endif
    }
    // Диагностика ABI: адрес объекта, адрес vtable и первые слоты (только чтение памяти, интерфейсы не запрашиваются; probe() на 8.5 падает)
    string vtableInfo(uint slots = 30) {
        IFramedView&& v = _getView(false);
        if (v is null)
            return "нет";
        int_ptr obj = v.self;
        int_ptr vt = mem::int_ptr[obj];
        string r = formatInt(obj, "0x", 16) + " vt=" + formatInt(vt, "0x", 16) + " slots:";
        for (uint i = 0; i < slots; i++)
            r += " " + formatInt(mem::int_ptr[vt + i * sizeof_ptr], "0x", 16);
        return r;
    }
    string get_id() {
        return __id;
    }
    string get_title() {
        IFramedView&& v = _getView();
        return v is null ? string() : v.title().str;
    }
    uint get_hwnd() {
    #if ver < 8.3.12
        IFramedView&& v = _getView();
        if (v !is null) {
            IWindowView&& wv = v.unk;
            if (wv !is null)
                return wv.hwnd();
            IWindow&& wnd = v.unk;
            if (wnd !is null)
                return wnd.hwnd();
        }
    #endif
        return 0;
    }
    IV8ViewPosition&& position() {
        IFramedView&& v = _getView();
        if (v is null)
            return null;
        IContainedObject&& co = v.unk;
        if (co is null)
            return null;
        IFramedViewSite&& site = cast<IUnknown>(co.getSite());
        if (co is null)
            return null;
        IV8ViewPosition vp;
        site.getViewPosition(vp.vp);
        return vp;
    }
    IV8View&& get_parent() {
        IFramedView&& v = _getView();
        if (v !is null) {
            Guid pid;
            if (getViewParentID(v, pid))
                return getViewWrapper(pid);
        }
        return null;
    }
    array<IV8View&&>&& enumChilds() {
        IFramedView&& v = _getView();
        if (v is null)
            return null;
        array<IV8View&&> result;
        IViewLayouter&& vl = v.unk;
        diag("mdi", "enumChilds: layouter " + (vl is null ? "нет" : "есть"));
        if (vl !is null) {
            // Пробуем простые частные случаи
            ITabbedLayouter&& tabs = vl.unk;
            Guid newID;
            if (tabs !is null) {
                uint count = tabs.pagesCount();
                result.reserve(count);
                for (uint i = 0; i < count; i++) {
                    IFramedView&& pg = tabs.page(i);
                    if (pg is null)     // вкладка уже закрывается: платформа отдаёт пустой указатель
                        continue;
                    pg.getID(newID);
                    result.insertLast(getViewWrapper(newID));
                }
            } else {
                IViewSplitter&& vs = vl.unk;
                if (vs !is null) {
                    IFramedView&& view = vs.first();
                    if (view !is null) {
                        view.getID(newID);
                        result.insertLast(getViewWrapper(newID));
                    }
                    &&view = vs.second();
                    if (view !is null) {
                        view.getID(newID);
                        result.insertLast(getViewWrapper(newID));
                    }
                } else {
                    IMDIClient&& mdi = vl.unk;
                    diag("mdi", "enumChilds: не tabs/splitter, mdi " + (mdi is null ? "нет" : "есть"));
                    if (mdi !is null) {
                        diag("mdi", "enumChilds: mdi.childsIds.start=" + mdi.childsIds.start + " end=" + mdi.childsIds.end);
                        if (dbgOn()) {
                            for (uint q = 0; q < 40; q++) {
                                int_ptr p0 = mem::int_ptr[mdi.self + q * sizeof_ptr];
                                int_ptr p1 = mem::int_ptr[mdi.self + (q + 1) * sizeof_ptr];
                                if (p0 > 0x10000 && p1 > p0 && p1 - p0 <= 16 * 64 && ((p1 - p0) % 16) == 0) {
                                    GuidRef&& g0 = toGuid(p0);
                                    diag("mdi", "mdi vec? off=" + formatInt(q * sizeof_ptr, "0x", 3) + " n=" + ((p1 - p0) / 16) + " first=" + g0.ref);
                                }
                            }
                        }
                        //doLog("Search MDI childs list at " + formatInt(mdi.self, "0x", 2 * sizeof_ptr));
                        //MsgBox("Search MDI childs list at " + formatInt(mdi.self, "0x", 2 * sizeof_ptr));
                        if (mdi.childsIds.start > 0) {
                            for (GuidRef&& ids = toGuid(mdi.childsIds.start); ids < mdi.childsIds.end; &&ids = ids + 1)
                                result.insertAt(0, getViewWrapper(ids.ref));
                        }
                    } else {
                        // Неизвестный контейнер. Переберем всех потомков.
                        // Так как нам нужны только непосредственные потомки, для каждого
                        // потомка будем получать родителя, пока он не станет равным заданному
                        NoCaseSet ids;
                        ViewContextList views;
                        views.head = views.end = views.self;
                        diag("mdi", "enumChilds: enumAllChilds");
                        vl.enumAllChilds(views, true);
                        diag("mdi", "enumChilds: enumAllChilds готово");
                        {
                            string dd = "list self=" + formatInt(views.self, "0x", 16);
                            for (uint q = 0; q < 6; q++)
                                dd += " [" + q + "]=" + formatInt(mem::int_ptr[views.self + q * sizeof_ptr], "0x", 16);
                            dbgLog(dd);
                            int_ptr n0 = mem::int_ptr[views.self];
                            if (n0 > 0x10000) {
                                string d2 = "node0=" + formatInt(n0, "0x", 16);
                                for (uint q = 0; q < 4; q++)
                                    d2 += " [" + q + "]=" + formatInt(mem::int_ptr[n0 + q * sizeof_ptr], "0x", 16);
                                dbgLog(d2);
                            }
                        }
                        ViewContextListNodeRef&& pNode = toViewContextListNode(views.head);
                        while (pNode.self != views.self) {
                            IViewContext&& pContext = pNode.ref.view;
                            do {
                                IFramedView&& parentView = getViewContext(pContext).ref.parent;
                                parentView.getID(newID);
                                if (__id != newID) {
                                    IContainedObject&& co = parentView.unk;
                                    &&pContext = cast<IUnknown>(co.getSite());
                                    continue;
                                }
                            } while (false);
                            pContext.getID(newID);
                            string snewID = newID;
                            if (!ids.contains(snewID)) {
                                result.insertLast(getViewWrapper(newID));
                                ids.insert(snewID);
                            }
                            int_ptr del = pNode.self;
                            &&pNode = toViewContextListNode(pNode.ref.next);
                            free(del);
                        }
                    }
                }
            }
        }
        return result;
    }
    void merge(IV8View&& other, ViewPlacements place) {
        IFramedView&& v = _getView();
        if (v is null)
            return;
        IFramedView&& vo = other._getView();
        if (vo is null)
            return;
        IContainedObject&& co = v.unk;
        if (co !is null) {
            IFramedViewSite&& site = cast<IUnknown>(co.getSite());
            if (site !is null && site.canSplit())
                site.split(vo, place, true, -1);
        }
    }
    ViewContainerType get_isContainer() {
        IFramedView&& view = _getView();
        if (view !is null) {
            IViewLayouter&& vl = view.unk;
            if (vl !is null) {
                ITabbedLayouter&& tabs = view.unk;
                if (tabs !is null)
                    return vctTabbed;
                else {
                    IViewSplitter&& vs = view.unk;
                    if (vs !is null)
                        return vs.isHorizontal() ? vctTwoViewsHorz : vctTwoViewsVert;
                    else {
                        IMDIClient&& mdi = view.unk;
                        if (mdi !is null)
                            return vctMdiContainer;
                        else
                            return vctUnknown;
                    }
                }
            }
        }
        return vctNo;
    }
    string get_wndClass() {
        string result;
        uint hWnd = get_hwnd();
        if (hWnd > 0)
            result.setLength(GetClassName(hWnd, result.setLength(300), 300));
        return result;
    }
    bool get_visible() {
        return mainFrame.isViewVisible(__id);
    }
    void set_visible(bool vis) {
        mainFrame.showView(__id, vis);
    }
    IV8View&& get_activeChild() {
        IFramedView&& view = _getView();
        if (view is null)
            return null;
        IViewLayouter&& vl = view.unk;
        if (vl !is null) {
            Guid newID;
            &&view = vl.activeView();
            if (view !is null) {
                view.getID(newID);
                return getViewWrapper(newID);
            } else {
                ICommandTarget&& at;
                vl.activeTarget(at);
                if (at !is null) {
                    IViewContext&& vc = at.unk;
                    if (vc !is null) {
                        vc.getID(newID);
                        return getViewWrapper(newID);
                    } else {
                        &&view = at.unk;
                        if (view !is null) {
                            view.getID(newID);
                            return getViewWrapper(newID);
                        }
                    }
                }
            }
        }
        return null;
    }
    void activate() {
        mainFrame.activateView(__id);
    }
    void close(bool forceClose = false) {
        mainFrame.closeView(__id, forceClose);
    }
    ICmdUpdateResult&& getCmdState(string cmdGroupUUID, uint cmdNumber, int subCommandIdx = -1) {
        IFramedView&& view = _getView();
        if (view !is null) {
            ICommandReceiver&& recv = view.unk;
            if (recv !is null)
                return getCommandStateRecv(CommandID(Guid(cmdGroupUUID), cmdNumber), subCommandIdx, recv);
        }
        return null;
    }
    bool sendCommand(string cmdGroupUUID, uint cmdNumber, int subCommandIdx = 0) {
        IFramedView&& view = _getView();
        if (view !is null) {
            ICommandReceiver&& recv = view.unk;
            return sendCommandToCmdRecv(CommandID(Guid(cmdGroupUUID), cmdNumber), subCommandIdx, recv);
        }
        return false;
    }
    IViewDocument&& getDocument() {
        IFramedView&& view = _getView();
        if (view !is null) {
            IDocumentView&& w = view.unk;
            if (w !is null) {
                IDocument&& doc;
                w.document(doc);
                return getDocWrapper(doc);
            }
        }
        return null;
    }
    Variant getObject() {
        Variant res;
        IFramedView&& view = _getView();
        if (view !is null) {
            IDocumentView&& w = view.unk;
            if (w !is null) {
                IDocument&& doc;
                w.document(doc);
                if (doc !is null) {
                    Value val;
                    &&val.pValue = doc.unk;
                    if (val.pValue !is null)
                        val2var(val, res);
                }
            }
        }
        return res;
    }
    IV8Form&& getInternalForm() {
        IFramedView&& view = _getView();
        if (view !is null) {
            IForm&& form = view.unk;
            if (form !is null)
                return IV8Form(form);
        }
        return null;
    }
    protected Variant pict;
    Variant get_icon() {
        IFramedView&& view = _getView();
        if (view !is null) {
            if (pict.vt == VT_EMPTY) {
                IUnknown&& unk;
                view.icon(unk);
                pict = image2pict(unk);
            }
        }
        return pict;
    }
    protected IV8MDObject&& myMdObj;
    IV8MDObject&& get_mdObj() {
        IFramedView&& view = _getView();
        if (view is null)
            return null;
        if (myMdObj is null)
            &&myMdObj = getMDObjectWrapper(getMdObjFromView(view));
        return myMdObj;
    }
    protected IV8MDProperty&& myMdProp;
    IV8MDProperty&& get_mdProp() {
        IFramedView&& view = _getView();
        if (view is null)
            return null;
        if (myMdProp is null)
            &&myMdProp = getMDPropWrapper(mdService.mdProp(getMdPropIDFromView(view)));
        return myMdProp;
    }
};

ViewContextRef&& getViewContext(IViewContext&& ctx) {
    Guid id;
    ctx.getID(id);
    //doLog("ViewContextOffset: искать от 0x" + formatInt(ctx.self, "0x", sizeof_ptr * 2) + " " + id);
    //MsgBox("ViewContextOffset: искать от 0x" + formatInt(ctx.self, "0x", sizeof_ptr * 2) + " " + id);
    return toViewContext(ctx.self + ViewContextOffset);
}

bool getViewParentID(IFramedView&& view, Guid& pid) {
    IFramedView&& parent = frameViewParent(view);
    if (parent !is null) {
        parent.getID(pid);
        return true;
    }
    return false;
}

IFramedView&& frameViewParent(IFramedView&& view) {
    IContainedObject&& co = view.unk;
    if (co !is null) {
        IViewContext&& ctx = cast<IUnknown>(co.getSite());
        if (ctx !is null) {
            //MsgBox("Check " + mem::addressOf(getViewContext(ctx).ref.parent));
            IFramedView&& object = cast<IUnknown>(getViewContext(ctx).ref.parent);
            return object;
        }
    }
    return null;
}

class IV8ViewPosition {
    ViewPosition vp;
    // в документации свойства есть, но не были портированы (скрипты получали ошибку)
    int get_state() {
        return int(vp.state);
    }
    // Сторона прикрепления (ViewPlacements: 1 слева, 2 сверху, 4 справа, 8 снизу, 16 по центру, 32 закладками)
    int get_area() {
        return int(vp.area);
    }
    bool get_mdiMax() {
        return vp.MDI_maxed;
    }
}

IViewDocument&& getDocWrapper(IDocument&& d) {
    return IViewDocument(d);
}

class IViewDocument {
    protected IDocument&& doc;
    IViewDocument(IDocument&& d) {
        &&doc = d;
    }
    bool saveToFile(const string& path) {
        if (doc is null) return false;
        IV8DataFile&& file = oneDesigner._v8files.open("file://" + path, FileOpenModes(fomTruncate | fomIn | fomOut));
        if (file is null) return false;
        ExceptionCatcher catcher;
        CppCatch c("class core::Exception", ExceptionHandler(catcher.handle));
        doc.save(file.file);
        file.close();
        if (catcher.hasException) {
            setComException(catcher.errStr);
            return false;
        }
        return true;
    }
    bool loadFromFile(const string& path) {
        if (doc is null) return false;
        IV8DataFile&& file = oneDesigner._v8files.open("file://" + path, FileOpenModes(fomIn | fomShareRead));
        if (file is null) return false;
        ExceptionCatcher catcher;
        CppCatch c("class core::Exception", ExceptionHandler(catcher.handle));
        doc.load(file.file);
        file.close();
        if (catcher.hasException) {
            setComException(catcher.errStr);
            return false;
        }
        return true;
    }
};

////////////////////////////////////////////////////////////////////////////////
// Перехват и оповещение о смене заголовка основного окна
void setTrapOnChangeTitle() {
    trMainFrame_setTitle.setTrap(coreMainFrame, ITopLevelFrame_setTitle, MainFrame_setTitle);
    trMainFrame_setAddTitle.setTrap(coreMainFrame, ITopLevelFrame_setAdditionalTitle, MainFrame_setAdditionalTitle);
}
TrapVirtualStdCall trMainFrame_setTitle;
TrapVirtualStdCall trMainFrame_setAddTitle;
funcdef void MainFrame_st(ITopLevelFrame&, const v8string&in);

void MainFrame_setTitle(ITopLevelFrame&frame, const v8string&in str) {
    if (!fireFrameTitleChanged(str, frame.getAdditionalTitle())) {
        MainFrame_st&& original;
        trMainFrame_setTitle.getOriginal(&&original);
        original(frame, str);
    }
}

void MainFrame_setAdditionalTitle(ITopLevelFrame&frame, const v8string&in str) {
    if (!fireFrameTitleChanged(frame.getTitle(), str)) {
        MainFrame_st&& original;
        trMainFrame_setAddTitle.getOriginal(&&original);
        original(frame, str);
    }
}

// Оповещение о событии изменения заголовка основного окна.
bool fireFrameTitleChanged(const string&in mainTitle, const string&in additionalTitle) {
    ISetMainTitleHook param;
    param._mainTitle = mainTitle;
    param._additionalTitle = additionalTitle;
    array<Variant> args(1);
    args[0].setDispatch(createDispatchFromAS(&&param));
    oneDesigner._events.fireEvent(dspWindows, "onChangeTitles", args);
    return param.cancel;
}

// Объект с параметрами оповещения об изменении заголовка основного окна.
// Подписчик может сам изменить заголовок окна через windows.caption, и установить
// cancel в true, чтобы отменить штатную обработку события
class ISetMainTitleHook {
    //[propget, helpstring("Основной заголовок")]
    string _mainTitle;
    //[propget, helpstring("Дополнительный заголовок")]
    string _additionalTitle;
    //[propget, helpstring("Отказ")]
    bool cancel = false;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////
// Перехват и оповещение о предупреждении
TrapVirtualStdCall trMsgBox;
void setTrapOnMsgBox() {
    trMsgBox.setTrap(getBkEndUI(), IBkEndUI_messageBox, msgBoxTrap);
}

int msgBoxTrap(IBkEndUI& pUI, const v8string& text, int_ptr type, int_ptr timeout, int_ptr caption, int_ptr parent, mbp&inout param,
    int_ptr i1, int_ptr i2, int_ptr i3
#if ver >= 8.3
               , int_ptr i4, int_ptr i5
#endif
               ) {
    // Для начала снимем перехват. Тогда обработчики события смогут также вызывать MsgBox без зацикливания
    trMsgBox.swap();
    if (oneDesigner._events._hasHandlers(dspWindows, "onMessageBox")) {
        // Если есть подписанты, оповестим их
        IMsgBoxHook params;
        params._text = text;
        params._caption = stringFromAddress(caption);
        params._type = type;
        params._timeout = timeout;
        array<Variant> args(1);
        args[0].setDispatch(createDispatchFromAS(&&params));
        oneDesigner._events.fireEvent(dspWindows, "onMessageBox", args);
        if (params.cancel) {
            // Подписанты отменили показ предупреждения.
            // Восстановим перехват
            trMsgBox.swap();
            return params.result;
        }
    }
    // Вызовем штатную процедуру
    int res = pUI.messageBox(text, type, timeout, caption, parent, param, i1, i2, i3
#if ver >= 8.3
                   , i4, i5
#endif
                   );
    // Восстановим перехват
    trMsgBox.swap();
    return res;
}
// Объект с параметрами оповещения о Предупреждении
class IMsgBoxHook {
    //[propget, helpstring("Заголовок")]
    string _caption;
    //[propget, helpstring("Текст")]
    string _text;
    //[propget, helpstring("Тип (см. MsgBoxStyles)")]
    uint _type;
    //[propget, helpstring("Таймаут")]
    uint _timeout;
    //[propget, helpstring("Отказ")]
    bool cancel = false;
    //[propget, helpstring("Результат при отказе")]
    MsgBoxAnswers result;
};


////////////////////////////////////////////////////////////////////////////////////
// Перехват открытия окна (IBkEndUI::openView) и оповещение windows.onViewOpened.
// Оповещение приходит сразу после возврата штатного openView, до возврата в цикл сообщений: подписчик (аддин std/snegopat.js, настройка
// «Открывать расширения закладками в окне Конфигурация») успевает переставить окно до первой перерисовки, без мелькания.
TrapVirtualStdCall trOpenView;
bool openViewNotifying = false;
void setTrapOnOpenView() {
    trOpenView.setTrap(getBkEndUI(), IBkEndUI_openView, openViewTrap);
}

void openViewTrap(IBkEndUI& pUI, IFramedView& view, const ViewPosition& pos, int openIn, bool activate, const Guid& g
#if ver < 8.3.18
                  , const Rect& r
#endif
                  ) {
    // Снимаем перехват на время штатного вызова, чтобы вложенные открытия окон не зацикливались
    trOpenView.swap();
    pUI.openView(view, pos, openIn, activate, g
#if ver < 8.3.18
                 , r
#endif
                 );
    trOpenView.swap();
    if (!openViewNotifying && oneDesigner._events._hasHandlers(dspWindows, "onViewOpened")) {
        openViewNotifying = true;       // подписчик сам может открыть окно: повторно не оповещаем
        array<Variant> args(0);
        oneDesigner._events.fireEvent(dspWindows, "onViewOpened", args);
        openViewNotifying = false;
    }
}

////////////////////////////////////////////////////////////////////////////////////
// Перехват закрытия окна (ITopLevelFrame::closeView) и оповещение windows.onViewClosed.
// onChangeTitles при закрытии окон не приходит (заголовок главного окна от MDI-окон не зависит, проверено на 8.3.27), поэтому панель окон
// узнавала о закрытии только опросом раз в 2 с. Оповещение приходит сразу после возврата штатного closeView, если окно закрыто.
// Перехват ставится на оба фрейма (основной и core), если у них разные таблицы виртуальных методов.
TrapVirtualStdCall trCloseView;
TrapVirtualStdCall trCloseViewCore;
void setTrapOnCloseView() {
    if (mainFrame is null)
        return;
    trCloseView.setTrap(mainFrame, ITopLevelFrame_closeView, closeViewTrap);
    if (coreMainFrame !is null && mem::int_ptr[coreMainFrame.self] != mem::int_ptr[mainFrame.self])
        trCloseViewCore.setTrap(coreMainFrame, ITopLevelFrame_closeView, closeViewTrapCore);
}

bool closeViewTrap(ITopLevelFrame& frame, const Guid& id, bool force) {
    trCloseView.swap();
    bool res = frame.closeView(id, force);
    trCloseView.swap();
    fireViewClosed(res, "main");
    return res;
}

bool closeViewTrapCore(ITopLevelFrame& frame, const Guid& id, bool force) {
    trCloseViewCore.swap();
    bool res = frame.closeView(id, force);
    trCloseViewCore.swap();
    fireViewClosed(res, "core");
    return res;
}

void fireViewClosed(bool closed, const string& src) {
    diag("closeview", src + ": closeView -> " + (closed ? "закрыто" : "отказ"));
    if (!closed || !oneDesigner._events._hasHandlers(dspWindows, "onViewClosed"))
        return;
    array<Variant> args(0);
    oneDesigner._events.fireEvent(dspWindows, "onViewClosed", args);
    wakeIdle();         // подписчик обновляет список на ближайшем простое: не ждём клика или мигания курсора
}

////////////////////////////////////////////////////////////////////////////////////
// Перехват и оповещение о Сообщить
void setTrapOnMessage() {
    //Павлюков - убрал коммент - иначе выводит сообщение и не переходит
    trMessage.setTrap(getBkEndUI(), IBkEndUI_doMsgLine, doMsgLineTrap);
}

TrapVirtualStdCall trMessage;

int doMsgLineTrap(IBkEndUI& pUI, const v8string&in text, int_ptr marker, const Guid&in g, int_ptr i1, IUnknown& pUnkObject, const V8Picture&in customMarker) {
    //Print(text.str);//Павлюков - иначе выводит сообщение, когда надо было спрятать
    // Для начала снимем перехват. Тогда обработчики события смогут также вызывать Message без зацикливания
    trMessage.swap();
    if (oneDesigner._events._hasHandlers(dspWindows, "onMessage")) {
        // Если есть подписанты, оповестим их
        IMessageParams params;
        params._text = text;
        params._marker = MessageMarker(marker);
        array<Variant> args(1);
        args[0].setDispatch(createDispatchFromAS(&&params));
        oneDesigner._events.fireEvent(dspWindows, "onMessage", args);
        if (params.cancel) {
            // Подписанты отменили показ предупреждения.
            // Восстановим перехват
            trMessage.swap();
            return 0;
        }
    }
    // Вызовем штатную процедуру
    int res = pUI.doMsgLine(text, marker, g, i1, pUnkObject, customMarker);
    // Восстановим перехват
    trMessage.swap();
    return res;
}

class IMessageParams {
    string _text;
    MessageMarker _marker;
    bool cancel = false;
};
