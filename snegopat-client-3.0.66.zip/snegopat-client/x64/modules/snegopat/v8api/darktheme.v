// Native renderer: no script callbacks from painting threads.
#if x86 = 0
:global
:dlls snegopat_theme.dll
    int nativeSelectPalette(int index)|themeSelectPalette
    int nativeThemeRefresh()|themeRefresh
    int nativeThemeColor(int slot, uint color)|themeCustomColor
    int nativeThemeCustom(int light)|themeCustomApply
    int64 nativeThemeCounter(uint kind)|themeCounter
#endif
