﻿// (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
// Описание интерфейсов 1С.

// Описание интерфейсов работы с событиями
:iface IEventRecipient {D15F2BB0-BD08-11d3-B950-008048DA0334}
:virt
	void onEvent(const Guid&in eventID, long val, IUnknown& obj)

:service IEventService {EBF766AA-F32C-11D3-9851-008048DA1252}
:virt
	// Рассылка уведомления о событии
#if ver < 8.3.24
	void  notify(const Guid&in eventID, long val=0, IUnknown@ obj=null)
#else
	// 8.3.24+ (x64): val несёт адрес структуры события (MDEventInfo), 32-битный long обрезал его и ронял получателей; нужен размер указателя
	void  notify(const Guid&in eventID, int_ptr val=0, IUnknown@ obj=null)
#endif
	// Подписка на событие
#if ver < 8.3.24
	void  subscribe(const Guid&in eventID, IEventRecipient@ pRecipient)
#else
	// 8.3.24+: метод принимает ещё имя источника (const char*) и число; с NULL в имени платформа падает (strlen).
	// Родная сигнатура под именем _subscribe, прежняя — обёрткой ниже (в 8.3.24-27 найдено по core83.dll, не по документации)
	void  _subscribe(const Guid&in eventID, IEventRecipient@ pRecipient, int_ptr srcName, int srcFlag)
#endif
	// Отписка от события
	void  unsubscribe(const Guid&in eventID, IEventRecipient@ pRecipient)
#if ver >= 8.3.24
:meths
	void subscribe(const Guid&in eventID, IEventRecipient@ pRecipient)
	{
		string srcName = "snegopat";
		obj._subscribe(eventID, pRecipient, srcName.cstr, 0);
	}
	---
#endif
:global
:meths
    IEventService@ getEventService()
    {
        return currentProcess().getService(IID_IEventService);
    }
    ---

// Сервис позволяющий подписаться на получение уведомлений о простое программы
:iface IIdleService {6B1FFDD4-36BE-11D4-9859-008048DA1252}
:virt
	+2
	#if ver < 8.3.10
    void addIdleHandler(IIdleHandler@ handler)
    void removeIdleHandler(IIdleHandler@ handler)
	#else
    void addIdleHandler(IIdleHandler@& handler)
    void removeIdleHandler(IIdleHandler@& handler)
	#endif
	+1
	void postEvent(const Guid& id, int val = 0, IUnknown@+ obj=null)
:global
:meths
    IIdleService@ getIdleService()
    {
        return currentProcess().getService(IID_IIdleService);
    }
    ---

// Подписчик на получение уведомлений о простое должен реализовать этот интерфейс.
// unknown должно возвращать 7
:iface IIdleHandler {6B1FFDD6-36BE-11D4-9859-008048DA1252}
:virt
    bool onIdle(int count)
	int unknown()

:enum IdleHandlerAnswer
#if ver <= 8.3.5
	7 idleHandlerUnknownFuncAnswer
#else
	0 idleHandlerUnknownFuncAnswer
#endif

// Интерфейс позволяет отменить закрытие приложения, с возможностью его спрятать
// Приходит в onEvent как obj в событии eventBeforeExitApp
:iface IAppExitCancel {85097440-4AD8-11D6-B231-0050BAE2BC79}
:virt
	void cancelExit(bool hide=false)

:guid eventCreateFrame		{3573FFE0-2FFF-11D5-BF5E-0050BAE2BC79}
:guid eventBeforeExitApp	{18B3F170-4979-11D6-B22B-0050BAE2BC79}
:guid eventExitApp			{18b3f171-4979-11D6-B22B-0050BAE2BC79}
