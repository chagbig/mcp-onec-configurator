﻿// (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
// ABI 8.5.1 adapted from fishca/v8snack v1.6.42 (MIT); see V8SNACK-LICENSE.txt.
// Описание интерфейсов 1С.

// ABI 8.5.1 подготовлен для проверки; runtime-допуск остаётся в engine/main.as.
#if ver < 8.2.19 | (ver > 8.3.0 & ver < 8.3.4) | (ver >= 8.3.28 & ver < 8.5.1) | ver >= 8.5.2
#err Unsupported version of 1C - Эта версия 1С не поддерживается!
#endif

:guid IID_NULL {00000000-0000-0000-0000-000000000000}

// Описание интерфейсов работы с процессом
:service SCOM_Process {EBF766A9-F32C-11D3-9851-008048DA1252}
:virt
    +1
    bool createByName(const v8string&in clsName, const Guid&in iid, IUnknown@&out ppObject)
    bool createByClsid(const Guid&in clsid, const Guid&in iid, IUnknown@&out ppObject)
    bool aggregateInstance(const Guid&in clsid, IUnknown@ pOuter, IUnknown@&out ptr)
    +1
    int getCategoryClasses(Vector& clsids, const Guid& clsid)
    +3
    bool registerService(const Guid&in, const Guid&in)
    +1
    IUnknown@+ getService(const Guid&in idService)
    +2
    uint32 loadComponent(uint32 name)


:struct Exception
	:props
		Guid		id
		v8string	descr
		uint		ptr

:global
:dlls
#if ver < 8.3
    core82.dll
#elif ver < 8.5
    core83.dll
#else
    core85.dll
#endif
    SCOM_Process@ currentProcess()|?current_process@core@@YAPAVSCOM_Process@1@XZ|?current_process@core@@YAPEAVSCOM_Process@1@XZ
	void val2var(const Value&, Variant&)|?value_to_variant_val@core@@YAXABVGenericValue@1@AAUtagVARIANT@@@Z|?value_to_variant_val@core@@YAXAEBVGenericValue@1@AEAUtagVARIANT@@@Z
#if ver < 8.3.11
	v8string load_module_wstring(int_ptr charNameModule, int_ptr charResID)|?load_module_wstring@core@@YA?AV?$basic_string@_WV?$char_traits@_W@stlp_std@@V?$allocator@_W@2@@stlp_std@@PBD0@Z
#elif ver < 8.3.20
	v8string load_module_wstring(int_ptr charNameModule, int_ptr charResID)|?load_module_wstring@core@@YA?AV?$basic_string@_SU?$fix_char_traits@_S@stdx@@V?$allocator@_S@std@@@stdx@@PBD0@Z|?load_module_wstring@core@@YA?AV?$basic_string@_SU?$fix_char_traits@_S@stdx@@V?$allocator@_S@std@@@stdx@@PEBD0@Z
#elif ver < 8.3.24
	v8string load_module_wstring(int_ptr charNameModule, int_ptr charResID)|?load_module_wstring@core@@YA?AV?$BasicString@_S$0A@$0A@Vallocator@std@@@ale@@PBD0@Z|?load_module_wstring@core@@YA?AV?$BasicString@_S$0A@$0A@Vallocator@std@@@ale@@PEBD0@Z
#else
	// 8.3.24+: у функции появился третий параметр bool (имя заканчивается на _N). Проверено по экспортам 8.3.24/26/27
	v8string load_module_wstring(int_ptr charNameModule, int_ptr charResID, bool=false)|?load_module_wstring@core@@YA?AV?$BasicString@_S$0A@$0A@Vallocator@std@@@ale@@PBD0_N@Z|?load_module_wstring@core@@YA?AV?$BasicString@_S$0A@$0A@Vallocator@std@@@ale@@PEBD0_N@Z
#endif

#if ver < 8.3.6
	void var2val(const Variant&, Value&, int i=0)|?variant_to_value@core@@YAXAAUtagVARIANT@@AAVGenericValue@1@H@Z
#else
	void var2val(const Variant&, Value&, int=0, bool=false)|?variant_to_value@core@@YAXAAUtagVARIANT@@AAVGenericValue@1@H_N@Z|?variant_to_value@core@@YAXAEAUtagVARIANT@@AEAVGenericValue@1@H_N@Z
#endif

:global
:dlls
#if ver < 8.3
	stl82.dll
	int_ptr malloc(size_t)|?__stl_new@stlp_std@@YAPAXI@Z
	void free(int_ptr)|?__stl_delete@stlp_std@@YAXPAX@Z
#elif ver < 8.3.11
	nuke83.dll
	int_ptr malloc(size_t)|?alloc@details@nuke@@YAPAXI@Z
	void free(int_ptr)|?free@details@nuke@@YAXPAX@Z
#elif ver < 8.3.20
	ucrtbase.dll
	int_ptr malloc(size_t)|malloc
	void free(int_ptr)|free
#elif ver < 8.5
	// 8.3.20+: платформа выделяет и освобождает память своим аллокатором (nuke83.dll); освобождать её CRT-free нельзя — повреждение кучи (0xC0000374)
	nuke83.dll
	int_ptr malloc(size_t)|nuke_malloc
	void free(int_ptr)|nuke_free
#else
	// 8.5+: ядро переименовано в nuke85.dll (экспорты nuke_malloc/nuke_free сохранены)
	nuke85.dll
	int_ptr malloc(size_t)|nuke_malloc
	void free(int_ptr)|nuke_free
#endif

:iface IGlobalContext {151C4C40-37A4-48EA-990C-14B584EF8A6C}
:virt
	+1

:iface IGlobalContextInit {845491E6-70AF-4495-B4E2-D77AC794E797}
:virt
    void init(IInfoBase& infoBase)

:global
:dlls Dbghelp.dll
	uint UnDecorateSymbolName(int_ptr mangled, int_ptr demangled, uint len, uint flags)|UnDecorateSymbolNameW

:global
:dlls Kernel32.dll
	// для диагностики адаптации (engine/com_metadata.as dbgDumpVT): безопасное чтение памяти без падения
	stdcall int ReadProcessMemory(int_ptr hProcess, int_ptr baseAddr, int_ptr buf, int_ptr size, int_ptr nRead)|ReadProcessMemory
	// память ниже 4 ГБ: snegopat.dll принимает указатели на текст как 32-битные (parseModuleText(uint textPtr…))
	stdcall uint GetCurrentThreadId()|GetCurrentThreadId
	stdcall int_ptr VirtualAlloc(int_ptr addr, int_ptr size, uint allocType, uint protect)|VirtualAlloc
	stdcall int VirtualFree(int_ptr addr, int_ptr size, uint freeType)|VirtualFree
