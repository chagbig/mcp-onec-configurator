﻿// Системное меню окна (WinAPI user32). Нужно для пункта «Настройки Снегопата» в системном меню главного окна Конфигуратора.
// Описания вынесены из main/api/winapi.v, чтобы не трогать общий файл.
:global
:dlls user32.dll
	stdcall HMENU GetMenu(HWND hWnd)|GetMenu
	stdcall HMENU GetSystemMenu(HWND hWnd, BOOL bRevert)|GetSystemMenu
	stdcall BOOL IsMenu(HMENU hMenu)|IsMenu
	stdcall int GetMenuItemCount(HMENU hMenu)|GetMenuItemCount
	stdcall BOOL AppendMenu(HMENU hMenu, UINT uFlags, int_ptr uIDNewItem, int_ptr lpNewItem)|AppendMenuW
	stdcall UINT GetMenuItemID(HMENU hMenu, int nPos)|GetMenuItemID
	stdcall BOOL GetCursorPos(Point& lpPoint)|GetCursorPos
