﻿//engine: JScript
//uname: styles
//dname: Палитры оформления
//author: codex
//addin: global
//descr: Просмотр и редактирование палитр Конфигуратора
global.connectGlobals(SelfScript);
var model=require("./std/style_model");
var catalogKey="Snegopat/Styles/Catalog";
profileRoot.createValue(catalogKey,"",pflSnegopat);
var controller;
var previewDraft=null;
function option(name,value) {
    var entry=snegopat.optionEntries;
    while(entry){if(entry.name==name){entry.doApply(value);return;}entry=entry.next;}
    throw new Error("Недоступна настройка "+name);
}
function userStyles(){return model.decode(String(profileRoot.getValue(catalogKey)));}
function allStyles(){
    var items;
    try{items=model.presets().concat(userStyles());}catch(e){items=model.presets();}
    if(previewDraft){
        for(var i=0;i<items.length;i++)if(items[i].id==previewDraft.style.id){items[i]=model.copy(previewDraft.style);return items;}
        items.push(model.copy(previewDraft.style));
    }
    return items;
}
function findStyle(id,items){for(var i=0;i<items.length;i++)if(items[i].id==id)return items[i];return null;}
function applyStyle(style) {
    if(!model.builtin(style.id)){model.validate(style);option("PaletteColors",model.payload(style));}
    option("ColorPalette",style.id);saveProfile();
}
function notifySettings(){
    var item=addins.byUniqueName("snegopatwnd");
    if(item){var driver=item.object().pageDrivers.Settings;if(driver && driver.StylesSaved)driver.StylesSaved();}
}
function previewStyle(id){
    var style=findStyle(id,allStyles());
    if(!style)throw new Error("Палитра не найдена");
    if(!model.builtin(id))model.validate(style);
    snegopat.previewPalette(id,model.builtin(id)?"":model.payload(style));
}
function restorePreview(){
    previewDraft=null;
    snegopat.previewPalette(String(profileRoot.getValue("Snegopat/Settings/ColorPalette")),
        String(profileRoot.getValue("Snegopat/Settings/PaletteColors")));
}
function saveCatalog(style,original){
    if(String(profileRoot.getValue(catalogKey))!=original)throw new Error("Каталог изменён в другом окне. Закройте палитру и откройте снова.");
    var items=userStyles(),kept=[],found=false;
    for(var i=0;i<items.length;i++){
        if(items[i].id==style.id){kept.push(style);found=true;}else kept.push(items[i]);
    }
    if(!found)kept.push(style);
    var encoded=model.encode(kept);
    profileRoot.setValue(catalogKey,encoded);
    if(String(profileRoot.getValue(catalogKey))!=encoded)throw new Error("Не удалось сохранить каталог");
    return encoded;
}
function commitPreview(id){
    if(!previewDraft)return;
    if(previewDraft.style.id!=id){previewDraft=null;return;}
    var style=model.copy(previewDraft.style);
    var encoded=saveCatalog(style,previewDraft.originalCatalog);
    applyStyle(style);previewDraft=null;
    if(controller && controller.style.id==id){controller.originalCatalog=encoded;controller.style=style;controller.items=model.presets().concat(userStyles());}
}
function hasPreviewDraft(){return previewDraft!=null;}
function newId(){return "custom:"+new Date().getTime()+"_"+Math.floor(Math.random()*1000000);}
function chooseFile(save){
    var dialog=v8New("FileDialog",save?FileDialogMode.Save:FileDialogMode.Open);
    dialog.Title=save?"Выгрузить палитру":"Загрузить палитру";
    dialog.Filter="Палитры JSON (*.json)|*.json";dialog.DefaultExt="json";
    if(save)dialog.FullFileName="palette.json";
    return dialog.Choose()?String(dialog.FullFileName):"";
}
function readJsonFile(path){
    var fs=new ActiveXObject("Scripting.FileSystemObject");
    if(fs.GetFile(path).Size>65536)throw new Error("Файл палитры слишком большой");
    var stream=new ActiveXObject("ADODB.Stream");
    stream.Type=2;stream.Charset="utf-8";stream.Open();
    try{stream.LoadFromFile(path);return stream.ReadText().replace(/^\uFEFF/,"");}finally{stream.Close();}
}
function writeJsonFile(path,text){
    var stream=new ActiveXObject("ADODB.Stream");
    stream.Type=2;stream.Charset="utf-8";stream.Open();
    try{stream.WriteText(text);stream.SaveToFile(path,2);}finally{stream.Close();}
    if(readJsonFile(path)!=text)throw new Error("Содержимое сохранённого файла не совпало с палитрой");
}
function StyleEditor(id,isNew){
    this.originalCatalog=String(profileRoot.getValue(catalogKey));
    this.items=allStyles();
    this.style=model.copy(findStyle(id,this.items) || model.builtin("standard"));
    if(isNew){this.style.id=newId();this.style.name=model.uniqueName("Новая палитра",this.items);}
    this.fixed=!!model.builtin(this.style.id);
    this.form=loadFormForScript(SelfScript,"",this,"",true);
    this.form.Controls.SaveCloseStyle.DefaultButton=true;
    this.form.Controls.SaveCloseStyle.Picture=БиблиотекаКартинок.ЗаписатьИЗакрыть;
    this.form.Controls.SaveStyle.Picture=БиблиотекаКартинок.Записать;
    this.form.Caption=this.fixed?"Палитра: "+this.style.name+" (просмотр)":"Палитра: "+this.style.name;
    this.form.Controls.StyleTitle.ТолькоПросмотр=this.fixed;
    this.form.Controls.Категории.ТолькоПросмотр=this.fixed;
    var names=["FillStyle","ImportStyle","SaveStyle","SaveCloseStyle","ApplyStyle"];
    for(var i=0;i<names.length;i++)this.form.Controls[names[i]].Доступность=!this.fixed;
    this.showStyle();
}
StyleEditor.prototype.showStyle=function(){
    this.form.StyleTitle=this.style.name;
    this.form.Категории.Очистить();
    for(var i=0;i<15;i++){
        var row=this.form.Категории.Добавить(),color=this.style.colors[i];
        row.Категория=String(i);row.Имя=model.roles[i];
        row.Цвет=v8New("Color",color&255,(color>>8)&255,(color>>16)&255);
    }
};
StyleEditor.prototype.read=function(){
    if(this.fixed)return model.copy(this.style);
    var style=model.copy(this.style);
    style.name=String(this.form.StyleTitle).replace(/^\s+|\s+$/g,"");
    for(var i=0;i<15;i++){
        var color=this.form.Категории.Получить(i).Цвет;
        var r=Number(color.Красный),g=Number(color.Зеленый),b=Number(color.Синий);
        if(r<0||g<0||b<0||r>255||g>255||b>255)throw new Error("Выберите абсолютный цвет RGB");
        style.colors[i]=r+g*256+b*65536;
    }
    return model.validate(style);
};
StyleEditor.prototype.fillFrom=function(id){
    if(this.fixed)return;
    var source=findStyle(id,this.items);
    if(!source)throw new Error("Палитра не найдена");
    this.style.name=String(this.form.StyleTitle);
    this.style.light=source.light;this.style.colors=source.colors.slice(0);this.showStyle();
};
StyleEditor.prototype.FillStyle=function(){
    var choices=v8New("ValueList");
    for(var i=0;i<this.items.length;i++)choices.Add(this.items[i].id,this.items[i].name);
    var selected=choices.ChooseItem("Заполнить по палитре");
    if(selected)this.fillFrom(String(selected.Value));
};
StyleEditor.prototype.importFile=function(path){
    if(this.fixed)throw new Error("Встроенная палитра доступна только для просмотра");
    this.style=model.importPalette(readJsonFile(path),this.style.id,this.items);this.showStyle();
};
StyleEditor.prototype.exportFile=function(path){writeJsonFile(path,model.exportPalette(this.read()));};
StyleEditor.prototype.ImportStyle=function(){try{var path=chooseFile(false);if(path)this.importFile(path);}catch(e){MessageBox(e.message);}};
StyleEditor.prototype.ExportStyle=function(){try{var path=chooseFile(true);if(path)this.exportFile(path);}catch(e){MessageBox(e.message);}};
StyleEditor.prototype.ApplyStyle=function(){
    if(this.fixed)return false;
    try{
        var style=this.read();
        // Validate names and catalog conflicts before changing the visible palette.
        var users=userStyles(),items=[];
        for(var i=0;i<users.length;i++)if(users[i].id!=style.id)items.push(users[i]);
        items.push(style);model.encode(items);
        if(String(profileRoot.getValue(catalogKey))!=this.originalCatalog)throw new Error("Каталог изменён в другом окне. Закройте палитру и откройте снова.");
        var item=addins.byUniqueName("snegopatwnd");
        if(!item)item=addins.loadAddin("script:addins/std/snegopatwnd.js",addins.sys);
        item.object().openPage("Settings");
        snegopat.previewPalette(style.id,model.payload(style));
        previewDraft={style:style,originalCatalog:this.originalCatalog};
        item.object().pageDrivers.Settings.StylePreviewed(style.id);
        return true;
    }catch(e){MessageBox(e.message);return false;}
};
StyleEditor.prototype.SaveStyle=function(){
    if(this.fixed)return false;
    try{
        var style=this.read(),encoded=saveCatalog(style,this.originalCatalog);
        this.originalCatalog=encoded;this.items=model.presets().concat(userStyles());this.style=style;
        previewDraft=null;
        this.form.Caption="Палитра: "+style.name;
        applyStyle(style);notifySettings();return true;
    }catch(e){MessageBox(e.message);return false;}
};
StyleEditor.prototype.SaveCloseStyle=function(){if(this.SaveStyle())this.form.Close(true);};
StyleEditor.prototype.CloseStyle=function(){this.form.Close(false);};
StyleEditor.prototype.Записать=function(){return this.SaveStyle();};
StyleEditor.prototype.ЗаписатьИЗакрыть=function(){return this.SaveCloseStyle();};
StyleEditor.prototype.ПриВыводеСтроки=function(element,appearance,data){appearance.val.Ячейки.Показ.ЦветФона=data.val.Цвет;};
function openForm(id,isNew){
    try{
        if(!id)id=String(profileRoot.getValue("Snegopat/Settings/ColorPalette"));
        if(controller && controller.form.IsOpen())controller.form.Close();
        controller=new StyleEditor(id,isNew);controller.form.Open();return true;
    }catch(e){MessageBox("Палитра: "+e.message);return false;}
}
function deletePalette(id){
    if(model.builtin(id))return false;
    if(previewDraft && previewDraft.style.id==id){restorePreview();notifySettings();}
    var items=userStyles(),kept=[],found=false;
    for(var i=0;i<items.length;i++)if(items[i].id==id)found=true;else kept.push(items[i]);
    if(!found)return false;
    var encoded=model.encode(kept);profileRoot.setValue(catalogKey,encoded);
    if(String(profileRoot.getValue(catalogKey))!=encoded)throw new Error("Не удалось сохранить каталог");
    if(String(profileRoot.getValue("Snegopat/Settings/ColorPalette"))==id)applyStyle(model.builtin("standard"));
    saveProfile();notifySettings();return true;
}
function macrosОткрытьПалитру(){openForm();}
function getDefaultMacros(){return "ОткрытьПалитру";}
exports.openForm=openForm;
exports.allStyles=allStyles;
exports.applyStyle=applyStyle;
exports.deletePalette=deletePalette;
exports.previewStyle=previewStyle;
exports.restorePreview=restorePreview;
exports.commitPreview=commitPreview;
exports.hasPreviewDraft=hasPreviewDraft;
