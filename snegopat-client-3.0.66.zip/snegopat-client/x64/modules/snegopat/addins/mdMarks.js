﻿//engine: JScript
//uname: mdMarks
//dname: Метки в дереве метаданных
//descr: Alt+F2 ставит и снимает метку на объекте в дереве метаданных, F2 и Shift+F2 переходят к следующей и предыдущей метке.
//author: Пушин Владимир <vladnet@gmail.com>
//help: inplace
//addin: global
//addin: stdlib
//addin: stdcommands

/*@
Метки в дереве метаданных. В типовых конфигурациях дерево огромное: ставишь метки на нужные объекты
и ходишь между ними, не раскрывая дерево руками.

Alt+F2: поставить метку на выделенный объект или снять, если она уже есть.
F2: перейти к следующей метке по порядку дерева (по кругу), Shift+F2: к предыдущей.

Клавиши работают только при фокусе в окне «Конфигурация». В остальных окнах (например, F2 в модуле)
клавиша уходит платформе как обычно. Метки хранятся в профиле Снегопата по пути из имён объектов:
переименованный или удалённый объект метку теряет (в переходах пропускается).
@*/

global.connectGlobals(SelfScript)

var legacyKey = "MdMarks/Paths"    // прежний общий список: переносится в списки конфигураций при первом обращении
var ctxId = "", ctxRoot = "", ctxView = ""   // окно дерева, с которым работаем: идентификатор корня конфигурации, его имя, идентификатор окна
var migrated = {}
var pathSep = "/"
// Трассировка шагов в файл logs\mdmarks-trace.txt (после падения Конфигуратора последняя строка показывает шаг, на котором он упал). Записывается до рискованных
// вызовов. Выключается значением traceOn
var traceOn = true
var traceRoot = null
function trace(text) {
    if (!traceOn)
        return
    try {
        if (traceRoot === null)
            traceRoot = String(env.snMainFolder).replace(/[\\/]+$/, "").replace(/[\\/]modules[\\/][^\\/]+$/i, "") + "\\logs"
        var file = new ActiveXObject("Scripting.FileSystemObject").OpenTextFile(traceRoot + "\\mdmarks-trace.txt", 8, true)
        file.WriteLine(new Date().getTime() + " " + text)
        file.Close()
    } catch (e) {}
}

// Раскладка IGrid сверена для 8.5.1.1343 (datasource.v: два новых слота после getCurrentLine, expandLine в слоте 47). Другие сборки 8.5
// не проверялись, там экспериментальные действия (раскрытие веток, звёздочки, удаление меток) выключены: остаются постановка метки и
// переход к видимым строкам
var legacyGrid = /^8\.5/.test(String(env.v8Version)) && String(env.v8Version) != "8.5.1.1343"
// Релиз 8.3.17 ведётся в остаточном режиме (решение владельца 2026-11-03): метки в дереве там работают криво, аддин выключен. Клавиши
// возвращаются платформе, звёздочки не рисуются. Возврат: поставить disabledOn17 = false (запись в tools/DISABLED-27.md)
var disabledOn17 = /^8\.3\.17\./.test(String(env.v8Version))
var markPrefix = "★ "    // добавляется движком к тексту помеченной строки дерева (engine/mark_paint.as)

// Чтение строк из скрипта через перехват движка (engine/mark_paint.as) на 8.3.17 иногда падает, поэтому на время чтений перехват
// снимается (quiet), а для раскрытия и сворачивания веток, где платформа строит строки и нужен префикс, возвращается (rebuilding).
// Старый движок без paintActive: тихо пропускаем
function setPaint(grid, on) {
    try {
        grid.paintActive(on)
    } catch (e) {}
}

var quietDepth = 0
function quiet(grid, action) {
    quietDepth++
    setPaint(grid, false)
    try {
        return action()
    } finally {
        quietDepth--
        if (quietDepth == 0)
            setPaint(grid, true)
    }
}

function rebuilding(grid, action) {
    setPaint(grid, true)
    try {
        return action()
    } finally {
        setPaint(grid, quietDepth == 0)
    }
}

// Окно дерева определяем по внутреннему типу, а не по заголовку (заголовок зависит от языка и признаков вроде «<!>»):
// объект метаданных окна принадлежит классу корня конфигурации, и у окна есть форма с гридом. Окна модулей конфигурации
// («… Модуль …») того же класса, но без грида
function isTreeView(view) {
    try {
        var obj = view.mdObj
        if (!obj)
            return false
        return String(obj.mdclass.id) == String(metadata.current.rootObject.mdclass.id)
    } catch (e) {
        return false
    }
}

// Грид окна дерева или null
function gridOfView(view) {
    try {
        if (!isTreeView(view))
            return null
        var form = view.getInternalForm()
        if (!form || form.controlsCount < 1)
            return null
        var grid = form.getControl(0).extInterface
        var rootRow = grid ? grid.dataSource.root.firstChild : null
        if (!rootRow)
            return null
        // Имя корня читаем только при смене окна: чтение строки на каждое нажатие клавиши давало AV в getCellFormat, если дерево перестраивалось
        var viewId = String(view.id)
        ctxId = String(view.mdObj.id)
        if (ctxView != viewId || !ctxRoot) {
            ctxRoot = quiet(grid, function () { return rowText(rootRow) })
            ctxView = viewId
        }
        return grid
    } catch (e) {
        return null
    }
}

// Грид дерева, если фокус сейчас в окне «Конфигурация»; иначе null
function treeGrid() {
    try {
        var view = windows.getFocusedView()
        return view ? gridOfView(view) : null
    } catch (e) {
        return null
    }
}

function rowText(row) {
    var text = String(row.getCellAppearance(0).text)
    return text.indexOf(markPrefix) == 0 ? text.substring(markPrefix.length) : text
}

// Имена от корня конфигурации до строки
function rowPath(row) {
    var parts = []
    for (var r = row, n = 0; r && n < 20; r = r.parent, n++)
        parts.unshift(rowText(r))
    return parts
}

// Метки хранятся в профиле отдельным списком на каждую конфигурацию (по идентификатору корня) без имени корня; наружу отдаются
// и принимаются полные пути «корень/вид/объект»
function marksKey() {
    return "MdMarks/" + ctxId
}

function readList(key) {
    profileRoot.createValue(key, v8New("СписокЗначений"), pflSnegopat)
    var list = profileRoot.getValue(key), items = []
    for (var i = 0; i < list.Count(); i++)
        items.push(String(list.Get(i).Value))
    return items
}

function writeList(key, items) {
    var list = v8New("СписокЗначений")
    for (var i = 0; i < items.length; i++)
        list.Add(items[i])
    profileRoot.setValue(key, list)
}

// Метки прежнего общего списка с именем корня этой конфигурации переносятся в её список
function migrateLegacy() {
    if (migrated[ctxId])
        return
    migrated[ctxId] = true
    var old = readList(legacyKey), own = readList(marksKey()), rest = [], moved = false
    for (var i = 0; i < old.length; i++) {
        if (old[i].indexOf(ctxRoot + pathSep) == 0) {
            var rel = old[i].substring(ctxRoot.length + 1)
            var has = false
            for (var k = 0; k < own.length; k++)
                if (own[k] == rel)
                    has = true
            if (!has)
                own.push(rel)
            moved = true
        } else
            rest.push(old[i])
    }
    if (moved) {
        writeList(marksKey(), own)
        writeList(legacyKey, rest)
    }
}

function loadMarks() {
    migrateLegacy()
    var items = readList(marksKey()), marks = []
    for (var i = 0; i < items.length; i++)
        marks.push(ctxRoot + pathSep + items[i])
    return marks
}

function saveMarks(marks) {
    var items = []
    for (var i = 0; i < marks.length; i++)
        if (marks[i].indexOf(ctxRoot + pathSep) == 0)
            items.push(marks[i].substring(ctxRoot.length + 1))
    writeList(marksKey(), items)
}

// Подпись метки для сообщений: путь без имени корня конфигурации
function markTitle(key) {
    var parts = key.split(pathSep)
    return parts.length > 1 ? parts.slice(1).join(" / ") : key
}

// Грид дерева конфигурации: сфокусированный или найденный среди окон (подсветка нужна и без фокуса в дереве)
function anyTreeGrid() {
    var grid = treeGrid()
    if (grid)
        return grid
    var found = null
    ;(function walk(view, depth) {
        if (!view || found || depth > 10)
            return
        found = gridOfView(view)
        if (found)
            return
        try {
            var childs = view.enumChilds()
            for (var i = 0; i < childs.count; i++)
                walk(childs.item(i), depth + 1)
        } catch (e) {}
    })(windows.mainView, 0)
    return found
}

// Передать движку пути меток: помеченные строки дерева получают префикс в тексте (engine/mark_paint.as).
// Старый движок без paintMarks: тихо пропускаем, остаётся только переход по меткам
var paintEnabled = true
var paintStarted = false    // перехват в этом сеансе уже ставился
var lastPushed = ""         // что последним передано движку (окна деревьев и список меток): одно и то же повторно не передаём
var paintedFor = {}         // окна деревьев, в которых построенные строки уже обновлены
var lastPaintOk = false     // последняя установка закончена: во всех деревьях строки обновлены (или меток нет)

// Все окна деревьев метаданных: основная конфигурация и расширения (у каждого свой корень и свой список меток)
function treeViews() {
    var list = []
    ;(function walk(view, depth) {
        if (!view || depth > 10)
            return
        if (isTreeView(view))
            list.push(view)
        try {
            var childs = view.enumChilds()
            for (var i = 0; i < childs.count; i++)
                walk(childs.item(i), depth + 1)
        } catch (e) {}
    })(windows.mainView, 0)
    return list
}

// Метки всех деревьев передаются движку одним списком (в путях первым элементом имя корня, деревья не пересекаются), и движок
// регистрирует источник каждого дерева. Раньше передавалось только одно дерево, и звёздочки в другом (например в расширении) пропадали
function paintMarks(grid) {
    if (!paintEnabled || legacyGrid || disabledOn17)
        return false
    var saved = { id: ctxId, root: ctxRoot, view: ctxView }
    lastPaintOk = false
    try {
        var trees = [], union = [], sig = []
        var views = treeViews()
        for (var v = 0; v < views.length; v++) {
            var g = gridOfView(views[v])
            if (!g)
                continue
            trees.push({ grid: g, key: ctxId + ctxView })
            sig.push(ctxView)
            union = union.concat(loadMarks())
        }
        if (!trees.length)
            return false
        lastPaintOk = true
        // Пока меток нет и перехват не ставился, движок не трогаем
        if (!union.length && !paintStarted)
            return true
        paintStarted = true
        trace("paint: деревьев " + trees.length + ", меток " + union.length)
        var pushed = sig.join(",") + "|" + union.join("\n")
        if (pushed != lastPushed) {
            lastPushed = pushed
            trace("paint: вызов движка paintMarks")
            for (var t = 0; t < trees.length; t++) {
                trees[t].grid.paintMarks(union.join("\n"), markPrefix)
                if (quietDepth > 0)
                    setPaint(trees[t].grid, false)     // перехват мог только что поставиться: на время чтений снова снимаем
            }
        }
        for (var u = 0; u < trees.length; u++) {
            if (paintedFor[trees[u].key])
                continue
            // Первая установка для этого окна: уже построенные строки обновляем. Текущей строки при запуске может ещё не быть (тогда
            // выделение не трогаем), а дерево может быть ещё не построено: «обновлено» запоминаем только после удачного обновления
            trace("paint: первое обновление дерева")
            var current = safeRead ? null : trees[u].grid.currentRow     // 8.3.x: текущую строку не читаем (AV в getCellFormat)
            if (refreshRow(trees[u].grid, current || null))
                paintedFor[trees[u].key] = true
            else
                lastPaintOk = false
        }
        return true
    } catch (e) {
        return false
    } finally {
        ctxId = saved.id
        ctxRoot = saved.root
        ctxView = saved.view
    }
}

// Строка дерева по пути из имён (первый элемент: имя корня), найденная заново. После раскрытия или сворачивания ветки платформа
// перестраивает строки, и прежние объекты строк (закладки) на 8.3.17 становятся негодными: обращение к ним роняет Конфигуратор
// внутри getCellFormat. Поэтому после любого раскрытия строки берём только такие, найденные заново. Не найдено: null
function rowByPath(grid, parts) {
    var row = grid.dataSource.root.firstChild
    if (!row || rowText(row) != parts[0])
        return null
    for (var i = 1; i < parts.length; i++) {
        var next = null
        for (var c = row.firstChild; c; c = c.next)
            if (rowText(c) == parts[i]) {
                next = c
                break
            }
        if (!next)
            return null
        row = next
    }
    return row
}

// Платформа запрашивает текст строк только при построении (раскрытие или сворачивание ветки), зато тогда пересобирает все видимые
// строки дерева. Поэтому для обновления префиксов у любой раскрываемой группы корня состояние переключается туда и обратно,
// после чего выделение возвращается
function refreshRow(grid, row) {
    if (legacyGrid)
        return false
    try {
        trace("refresh: путь строки")
        var rowParts = row ? rowPath(row) : null
        var root = grid.dataSource.root.firstChild, anchorName = null
        for (var c = root.firstChild; c && anchorName === null; c = c.next)
            if (c.firstChild)
                anchorName = rowText(c)
        if (anchorName === null)
            return false
        var anchorParts = [rowText(root), anchorName]
        var anchor = rowByPath(grid, anchorParts)
        if (!anchor)
            return false
        var was = grid.isExpanded(anchor)
        trace("refresh: expand " + anchorName + " " + !was)
        rebuilding(grid, function () { grid.expand(anchor, !was) })
        trace("refresh: поиск группы заново")
        anchor = rowByPath(grid, anchorParts)
        if (anchor) {
            trace("refresh: expand " + anchorName + " " + was)
            rebuilding(grid, function () { grid.expand(anchor, was) })
        }
        trace("refresh: поиск строки заново")
        var back = rowParts ? rowByPath(grid, rowParts) : null
        if (back) {
            trace("refresh: касание и выделение")
            rowText(back)
            grid.currentRow = back
        }
        trace("refresh: конец")
        return true
    } catch (e) {
        return false
    }
}

// Дочерние строки (имя + строка); parent == null: верхний уровень. Один обход на родителя
// Имена детей запоминаются между нажатиями (namesCache): каждое нажатие F2 раньше перечитывало сотни строк веток, а массовое чтение строк
// грида на 8.3.17 после серии переходов рано или поздно роняло платформу (AV в getCellFormat). Из кеша строки не берутся (row == null),
// их находят заново по пути. Кеш сбрасывается при смене окна и когда переход не удался
var namesCache = {}, namesCacheFor = ""
function childRows(grid, parent, key, cache) {
    if (cache[key])
        return cache[key]
    var scope = ctxId + "|" + ctxView
    if (namesCacheFor != scope) {
        namesCache = {}
        namesCacheFor = scope
    }
    var list = [], cached = namesCache[key]
    if (cached) {
        for (var i = 0; i < cached.length; i++)
            list.push({ name: cached[i], row: null })
    } else {
        trace("children: " + key + " раскрыта=" + (parent ? grid.isExpanded(parent) : "корень"))
        var names = []
        for (var r = parent ? parent.firstChild : grid.dataSource.root.firstChild; r; r = r.next) {
            var name = rowText(r)
            names.push(name)
            list.push({ name: name, row: r })
        }
        namesCache[key] = names
    }
    cache[key] = list
    return list
}

// Строка дерева по ключу метки: {key, row, chain (строки от корня), order (индексы среди соседей)} или null
function resolveKey(grid, key, cache) {
    var parts = key.split(pathSep), chain = [], order = [], parent = null
    for (var i = 0; i < parts.length; i++) {
        var levelKey = parts.slice(0, i).join(pathSep)
        // Предок взят из кеша имён: для чтения следующего уровня его строку находим заново
        if (i > 0 && !parent && !cache[levelKey] && !namesCache[levelKey])
            parent = rowByPath(grid, parts.slice(0, i))
        var level = childRows(grid, parent, levelKey, cache), idx = -1
        for (var k = 0; k < level.length; k++)
            if (level[k].name == parts[i]) {
                idx = k
                break
            }
        if (idx < 0)
            return null
        order.push(idx)
        parent = level[idx].row
        chain.push(parent)
    }
    return { key: key, row: parent, chain: chain, order: order }
}

function compareOrder(a, b) {
    var n = Math.min(a.order.length, b.order.length)
    for (var i = 0; i < n; i++)
        if (a.order[i] != b.order[i])
            return a.order[i] - b.order[i]
    return a.order.length - b.order.length
}

// Метки, найденные в дереве, в порядке дерева
function resolveMarks(grid, cache) {
    var marks = loadMarks(), found = []
    for (var i = 0; i < marks.length; i++) {
        var entry = resolveKey(grid, marks[i], cache)
        if (entry)
            found.push(entry)
    }
    found.sort(compareOrder)
    return found
}

function toggleMark() {
    var grid = treeGrid()
    if (!grid)
        return false
    return quiet(grid, function () { return toggleMarkIn(grid) })
}

function toggleMarkIn(grid) {
    var row = grid.currentRow
    if (!row || !row.parent)
        return true     // корень конфигурации не помечаем
    trace("toggle: путь строки")
    var key = rowPath(row).join(pathSep), marks = loadMarks(), at = -1
    for (var i = 0; i < marks.length; i++)
        if (marks[i] == key) {
            at = i
            break
        }
    if (at >= 0)
        marks.splice(at, 1)
    else
        marks.push(key)
    saveMarks(marks)
    trace("toggle: paintMarks")
    paintMarks(grid)
    trace("toggle: refreshRow")
    refreshRow(grid, row)
    trace("toggle: конец")
    return true
}

// Перейти к строке метки. На 8.3.27 присвоение currentRow молча не срабатывает, пока перед ним не прочитано оформление
// текущей и целевой строк (установка активной ячейки без «касания» игнорируется платформой), поэтому касаемся и проверяем итог
// На 8.3.17 чтение текущей строки сразу после присвоения currentRow (проверка итога, касание перед присвоением и поиск «где мы сейчас» при
// следующем нажатии) время от времени роняет платформу (AV в getCellFormat по битой закладке getCurrentLine). Там присвоение работает и
// без касания, поэтому текущую строку не читаем, а последнюю цель перехода помним сами (lastJump)
var safeRead = /^8\.3\.1\d/.test(String(env.v8Version))
var lastJump = { key: "", at: 0 }
function jumpTo(grid, target) {
    var parts = target.key.split(pathSep)
    trace("jump: " + target.key)
    // Если все предки уже раскрыты, строки с момента поиска не перестраивались и годятся; иначе (и при повторных попытках) строки ищем заново
    var fresh = false
    if (!legacyGrid)
        for (var c = 0; c < target.chain.length - 1 && !fresh; c++)
            if (!target.chain[c] || !grid.isExpanded(target.chain[c]))
                fresh = true
    for (var attempt = 0; attempt < 3; attempt++) {
        var row = target.row
        if (!row)
            fresh = true
        if (fresh || attempt > 0) {
            if (!legacyGrid)
                for (var depth = 1; depth < parts.length; depth++) {
                    trace("jump: предок " + depth)
                    var ancestor = rowByPath(grid, parts.slice(0, depth))
                    if (!ancestor)
                        return false
                    if (!grid.isExpanded(ancestor)) {
                        trace("jump: expand предка " + depth)
                        rebuilding(grid, function () { grid.expand(ancestor, true) })
                    }
                }
            trace("jump: строка заново")
            row = rowByPath(grid, parts)
            if (!row)
                return false
        }
        trace("jump: касание текущей")
        var current = safeRead ? null : grid.currentRow
        if (current)
            rowText(current)
        trace("jump: касание цели")
        rowText(row)
        trace("jump: присвоение")
        grid.currentRow = row
        trace("jump: проверка")
        if (safeRead) {
            lastJump = { key: target.key, at: new Date().getTime() }
            return true
        }
        var now = grid.currentRow
        if (now && rowPath(now).join(pathSep) == target.key) {
            lastJump = { key: target.key, at: new Date().getTime() }
            return true
        }
    }
    return false
}

// Убрать из списка метки, которых больше нет в дереве (объект удалён или переименован). Список принадлежит только этой
// конфигурации, поэтому всё, что не нашлось в дереве, удаляется. Возвращает, сколько меток удалено
function dropStaleMarks(entries) {
    var resolved = {}
    for (var i = 0; i < entries.length; i++)
        resolved[entries[i].key] = true
    var marks = loadMarks(), kept = []
    for (var m = 0; m < marks.length; m++)
        if (resolved[marks[m]])
            kept.push(marks[m])
    if (kept.length != marks.length)
        saveMarks(kept)
    return marks.length - kept.length
}

function removeMark(key) {
    var marks = loadMarks(), kept = []
    for (var i = 0; i < marks.length; i++)
        if (marks[i] != key)
            kept.push(marks[i])
    saveMarks(kept)
}

function goMark(step) {
    var grid = treeGrid()
    if (!grid)
        return false
    return quiet(grid, function () { return goMarkIn(grid, step) })
}

function goMarkIn(grid, step) {
    trace("goMark: paintMarks")
    paintMarks(grid)
    trace("goMark: resolveMarks")
    var cache = {}, entries = resolveMarks(grid, cache)
    trace("goMark: найдено меток " + entries.length)
    if (!legacyGrid && dropStaleMarks(entries))
        paintMarks(grid)
    if (!entries.length)
        return true
    trace("goMark: текущая строка")
    var hereKey = ""
    if (safeRead)
        hereKey = lastJump.key      // 8.3.17: текущую строку не читаем никогда (AV), идём от последней цели перехода, а при её отсутствии с первой/последней метки
    else {
        var current = grid.currentRow
        if (current)
            hereKey = rowPath(current).join(pathSep)
    }
    var here = hereKey ? resolveKey(grid, hereKey, cache) : null
    var target = null
    if (here) {
        if (step > 0) {
            for (var i = 0; i < entries.length && !target; i++)
                if (compareOrder(entries[i], here) > 0)
                    target = entries[i]
            if (!target)
                target = entries[0]
        } else {
            for (var j = entries.length - 1; j >= 0 && !target; j--)
                if (compareOrder(entries[j], here) < 0)
                    target = entries[j]
            if (!target)
                target = entries[entries.length - 1]
        }
    } else
        target = step > 0 ? entries[0] : entries[entries.length - 1]
    if (!jumpTo(grid, target) && !legacyGrid) {
        // Перейти не удалось: объекта уже нет (или дерево изменилось, кеш имён устарел), метку убираем из списка
        namesCache = {}
        removeMark(target.key)
        paintMarks(grid)
        var left = grid.currentRow
        if (left)
            refreshRow(grid, left)
    }
    return true
}

// Восстановление при открытии конфигурации: когда в Конфигураторе открывается окно, а также в течение 3 с на простое, пока дерево
// не будет найдено и метки не будут переданы движку (дерево строится не сразу). Звёздочки видны без нажатия клавиш
var restoreUntil = 0, restoreAt = 0, restored = {}
var treeSig = ""
function tryRestore() {
    restoreAt = new Date().getTime()
    try {
        // Пока открыто модальное окно (сообщение, диалог), платформа крутит вложенный цикл сообщений, и чтение строк грида из событий
        // открытия окна и простоя на 8.3.17 даёт AV (окно «Core.As»). Читаем после закрытия модального окна
        if (safeRead && Number(windows.modalMode) != 0)
            return false
        // Набор окон деревьев изменился (открыто или пересоздано окно расширения и т. п.): установка нужна заново
        var ids = [], views = treeViews()
        for (var i = 0; i < views.length; i++)
            ids.push(String(views[i].id))
        if (ids.join(",") != treeSig) {
            treeSig = ids.join(",")
            restored = {}
        }
        var grid = anyTreeGrid()
        if (!grid)
            return false
        if (!restored[ctxId + ctxView]) {
            quiet(grid, function () { paintMarks(grid) })
            // Успех: строки обновлены во всех деревьях или меток нет; иначе повторяем на простое (дерево строится не сразу)
            if (!lastPaintOk)
                return false
            restored[ctxId + ctxView] = true
        }
        return true
    } catch (e) {
        return false
    }
}
// При окончательной загрузке Снегопата окно дерева и его источник могут пересоздаваться уже после первой установки меток (звёздочки
// пропадали), поэтому на каждое открытие окна установка повторяется заново, а ждём дерево дольше
var restoreWait = 15000
events.connect(windows, "onViewOpened", function () {
    restored = {}
    paintedFor = {}
    lastPushed = ""
    if (tryRestore())
        restoreUntil = 0
    else
        restoreUntil = restoreAt + restoreWait
}, "-")
// Окно дерева может быть пересоздано без события onViewOpened (звёздочки пропадали до следующей постановки метки: идентификатор окна
// менялся, а движку метки передавались для прежнего). Поэтому и вне периода ожидания раз в 1.5 с на простое проверяем, что для
// текущего окна дерева метки уже установлены (tryRestore для установленного окна ничего не делает)
var watchAt = 0
events.connect(Designer, "onIdle", function () {
    var now = new Date().getTime()
    if (!restoreUntil) {
        if (now - watchAt >= 1500) {
            watchAt = now
            tryRestore()
        }
        return
    }
    if (now > restoreUntil) {
        restoreUntil = 0
        return
    }
    if (now - restoreAt >= 300 && tryRestore())
        restoreUntil = 0
}, "-")
if (!disabledOn17)
    tryRestore()

// Платформа во время нативных вызовов грида (раскрытие ветки, построение строк) обрабатывает сообщения, и быстрое повторное нажатие
// клавиши запускало макрос внутри ещё не завершённого прежнего (на 8.3.17 это давало AV в перехвате и окно ошибки Снегопата).
// Пока макрос выполняется, повторные запуски пропускаются, клавиша считается обработанной
var macroBusy = false
function guarded(action) {
    if (disabledOn17)
        return false        // 8.3.17: аддин выключен, клавиша уходит платформе
    if (macroBusy) {
        trace("макрос: пропущен, предыдущий ещё работает")
        return true
    }
    macroBusy = true
    trace("макрос: вход")
    try {
        return action()
    } catch (e) {
        // Нативный сбой чтения строки грида (строка устарела после перестроения дерева): окно ошибки Снегопата не показываем
        trace("макрос: ошибка " + (e && e.message ? e.message : e))
        return true
    } finally {
        macroBusy = false
        trace("макрос: выход")
    }
}

stdlib.createMacros(SelfScript.self, "Поставить или снять метку", "Метка на выделенном объекте в дереве метаданных",
    stdcommands.TextEdit.ToggleBookmark.info.picture, function () { return guarded(toggleMark) }, "Alt+F2")
stdlib.createMacros(SelfScript.self, "Следующая метка", "Перейти к следующей метке в дереве метаданных",
    stdcommands.TextEdit.ToggleBookmark.info.picture, function () { return guarded(function () { return goMark(1) }) }, "F2")
stdlib.createMacros(SelfScript.self, "Предыдущая метка", "Перейти к предыдущей метке в дереве метаданных",
    stdcommands.TextEdit.ToggleBookmark.info.picture, function () { return guarded(function () { return goMark(-1) }) }, "Shift+F2")

// Сочетания из createMacros Снегопат назначает при загрузке аддина только через эту функцию
function getPredefinedHotkeys(predef) {
    predef.setVersion(1)
    stdlib.getAllPredefHotKeys(SelfScript.self, predef)
}

// Подсветка включается при первой постановке метки или переходе; при загрузке аддина её нет, пока перехват не проверен живьём
