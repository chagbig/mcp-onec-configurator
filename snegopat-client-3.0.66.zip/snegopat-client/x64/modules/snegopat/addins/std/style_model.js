﻿//engine: JScript
//uname: style_model
//dname: Модель стилей оформления
// Pure data model; also exercised outside 1C with Node.
var roles = ["Основной фон", "Фон панелей", "Поверхность поля", "Граница поверхности", "Средний нейтральный", "Светлый нейтральный", "Самый светлый нейтральный", "Комментарий", "Идентификатор", "Ключевое слово", "Препроцессор", "Активное выделение", "Неактивное выделение", "Основной текст", "Отключённый элемент"];
function packed(hex) {
    var n = parseInt(hex, 16);
    return ((n >> 16) & 255) | (n & 65280) | ((n & 255) << 16);
}
function colors(text) {
    var parts = text.split(" "), result = [];
    for (var i = 0; i < parts.length; i++) result.push(packed(parts[i]));
    return result;
}
var builtinStyles = [
    {id:"standard", name:"Стандартная", light:1, colors:colors("FFFFFF DFDFDF BFBFBF 8C8C8C 606060 333333 000000 008000 0000FF FF0000 963200 536AC2 6F98CF 000000 808080")},
    {id:"ristretto", name:"Monokai Pro Ristretto", light:0, colors:colors("2C2525 211C1C 403838 5B5353 72696A 958A8B BDB0B1 72696A BDB0B1 FD6883 A8A9EB 5B5353 4A4242 BDB0B1 7D7374")},
    {id:"darkmodern", name:"VS Code Dark Modern", light:0, colors:colors("1F1F1F 181818 2B2B2B 3C3C3C 6E7681 9D9D9D CCCCCC 6A9955 9CDCFE 569CD6 C586C0 264F78 3A3D41 CCCCCC 808080")}
];
function copy(style) { return {id:style.id, name:style.name, light:style.light, colors:style.colors.slice(0)}; }
function builtin(id) { for (var i=0;i<builtinStyles.length;i++) if(builtinStyles[i].id==id)return copy(builtinStyles[i]); return null; }
function validate(style) {
    if (!style || typeof style.id!="string" || !/^custom:[a-zA-Z0-9_]+$/.test(style.id)) throw new Error("Неверный идентификатор стиля");
    if (typeof style.name!="string" || !style.name.replace(/^\s+|\s+$/g, "") || style.name.length>80) throw new Error("Название должно содержать от 1 до 80 символов");
    if (style.light!==0 && style.light!==1) throw new Error("Неверный тип палитры");
    if (!style.colors || style.colors.length!=15) throw new Error("Нужны все 15 цветов");
    for(var i=0;i<15;i++) if(typeof style.colors[i]!="number" || !isFinite(style.colors[i]) || Math.floor(style.colors[i])!=style.colors[i] || style.colors[i]<0 || style.colors[i]>16777215) throw new Error("Допустимы только абсолютные цвета RGB");
    return style;
}
function decode(text) {
    if(!text)return [];
    var data=JSON.parse(text), result=[], seen={}, names={};
    for(var n=0;n<builtinStyles.length;n++)names["$"+builtinStyles[n].name.toLowerCase()]=true;
    if(!data || data.version!==1 || !(data.items instanceof Array) || data.items.length>100)throw new Error("Неверный формат каталога стилей");
    for(var i=0;i<data.items.length;i++) {
        var item=validate(data.items[i]);
        if(seen[item.id])throw new Error("Повтор идентификатора стиля");
        var nameKey="$"+item.name.replace(/^\s+|\s+$/g, "").toLowerCase();
        if(names[nameKey])throw new Error("Название стиля уже используется");
        names[nameKey]=true;
        seen[item.id]=true;result.push(copy(item));
    }
    return result;
}
function encode(items) { return JSON.stringify({version:1, items:decode(JSON.stringify({version:1,items:items}))}); }
function payload(style) { return [style.light].concat(style.colors).join(";"); }
function uniqueName(name,items,exceptId) {
    var base=name.substring(0,65),candidate=base,suffix=1;
    while(true){
        var used=false;
        for(var i=0;i<items.length;i++)if(items[i].id!=exceptId && items[i].name.toLowerCase()==candidate.toLowerCase())used=true;
        if(!used)return candidate;
        candidate=base+" ("+(++suffix)+")";
    }
}
function rgbHex(color) {
    var value=((color&255)<<16)|(color&65280)|((color>>16)&255);
    return "#"+("000000"+value.toString(16).toUpperCase()).slice(-6);
}
function exportPalette(style) {
    var checked=copy(style);checked.id="custom:export";validate(checked);
    var values=[];
    for(var i=0;i<15;i++)values.push(rgbHex(style.colors[i]));
    return JSON.stringify({format:"snegopat-palette",version:1,palette:{name:style.name,light:style.light,colors:values}},null,2);
}
function importPalette(text,id,items) {
    if(typeof text!="string" || text.length>65536)throw new Error("Файл палитры слишком большой");
    var data=JSON.parse(text.replace(/^\uFEFF/,""));
    if(!data || data.format!="snegopat-palette" || data.version!==1 || !data.palette)throw new Error("Неизвестный формат файла палитры");
    var source=data.palette;
    if(!(source.colors instanceof Array) || source.colors.length!=15)throw new Error("В файле должны быть все 15 цветов");
    var style={id:id,name:source.name,light:source.light,colors:[]};
    for(var i=0;i<15;i++){
        if(typeof source.colors[i]!="string" || !/^#[0-9a-fA-F]{6}$/.test(source.colors[i]))throw new Error("Неверный цвет в файле палитры");
        style.colors.push(packed(source.colors[i].substring(1)));
    }
    validate(style);style.name=uniqueName(style.name,items,id);return style;
}
exports.roles=roles;
exports.presets=function(){return [builtin("standard"),builtin("ristretto"),builtin("darkmodern")];};
exports.builtin=builtin;
exports.copy=copy;
exports.validate=validate;
exports.decode=decode;
exports.encode=encode;
exports.payload=payload;
exports.uniqueName=uniqueName;
exports.exportPalette=exportPalette;
exports.importPalette=importPalette;
