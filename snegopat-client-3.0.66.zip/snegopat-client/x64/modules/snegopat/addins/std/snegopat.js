﻿//engine: JScript
//uname: SnegopatMainScript
//dname: Снегопат
//debug: no
//addin: global
//descr: Скрипт с основными макросами снегопата
//author: orefkov
//help: inplace
exports.__esModule = true;
/*
 * (c) проект "Snegopat.Module", Александр Орефков orefkov@gmail.com
 * Основной скрипт снегопата.
 */
/// <reference path="../snegopat.d.ts"/>
/// <reference path="../v8.d.ts"/>
/*@
В этом скрипте находятся основные макросы, которые предоставляет сам снегопат.
Он загружается из стартового скрипта предпоследним из служебных аддинов.
@*/
global.connectGlobals(SelfScript);
var macroswnd = require("./macroswnd");
var stdlib = require("./std");
var stdcommands = require("./commands");
stdlib.createMacros(SelfScript.self, "ВыбратьИВыполнитьМакрос", "Выбрать макрос из списка и выполнить его", stdcommands.CDebug.Start.info.picture, function () {
    var macrosesWnd = macroswnd.MacrosWnd();
    if (macrosesWnd.isOpened())
        return false;
    var res = macrosesWnd.selectMacros();
    if (res) {
        var a = addins.byUniqueName(res.addin);
        if (a)
            return a.invokeMacros(res.macros);
        Message("Аддин с именем " + res.addin + " не найден");
    }
});
// Создадим макросы для вставок текста
(function (textBefore, textAfter, hotKey, activateHint) {
    var nameOfinsert = textBefore;
    if (textAfter.length)
        nameOfinsert += "..." + textAfter;
    var nameOfMacros = "Редактирование\\Вставить " + nameOfinsert;
    stdlib.createMacros(SelfScript.self, nameOfMacros, "Вставить " + nameOfinsert + " в текущей позиции редактируемого текста", stdcommands.TextEdit.Templates.info.picture, (function (txtBefore, txtAfter, aHint) {
        return function () {
            return replaceSelInTxtWnd(txtBefore, txtAfter, aHint);
        };
    })(textBefore, textAfter, activateHint), hotKey);
    return arguments.callee;
})("<", "", "Alt + ,")(">", "", "Alt + .")("@", "", "Alt + 2")("#", "", "Alt + 3", false)("$", "", "Alt + 4")("^", "", "Alt + 6")("&", "", "Alt + 7", false)("Null", "", "Alt + N")("~", "", "Alt + ~")("[", "]", "Alt + [")("{", "}", "Alt + Shift + [")("]", "", "Alt + ]")("}", "", "Alt + Shift + ]")("'", "'", "Alt + '")('"', '"', "Alt + Shift + '")("=", "", "Alt + =");
stdlib.createMacros(SelfScript.self, "Разработка\\Сдампить SnegAPI в snegopat.d.ts", "Сформировать файл описания SnegAPI в формате TypeScript", undefined, function () {
    develop.dumpSnegApiToDts();
    MessageBox("Готово");
});
stdlib.createMacros(SelfScript.self, "Разработка\\Сдампить типы 1С в v8.d.ts", "Сформировать файл описания типов 1С в формате TypeScript", undefined, function () {
    develop.dumpV8typesToDts();
    MessageBox("Готово");
});
stdlib.createMacros(SelfScript.self, "Разработка\\Переключить трассировку команд", "Включает/выключает вывод отладочных сообщений при прохождении команд в главном окне 1С", undefined, function () {
    develop.cmdTrace = !develop.cmdTrace;
    MessageBox("Трассировка команд в" + (develop.cmdTrace ? "" : "ы") + "ключена", mbOK, "Снегопат", 1);
});
/*stdlib.createMacros(SelfScript.self, "Разработка\\TestCommand",
    "Открыть форму для исследования команд", undefined,
    function () {
        stdcommands.TestForm.open();
    });
*/
stdlib.createMacros(SelfScript.self, "Открыть окно Снегопата", "Открытие основного окна Снегопата", PictureLib.НастройкаСписка, function () {
    var a = addins.byUniqueName("snegopatwnd");
    if (!a)
        a = addins.loadAddin("script:addins\\std\\snegopatwnd.js", addins.sys);
    a.object().openWnd();
});
function openSnegopatPage(name) {
    var pageAddin = addins.byUniqueName("snegopatwnd");
    if (!pageAddin)
        pageAddin = addins.loadAddin("script:addins\\std\\snegopatwnd.js", addins.sys);
    pageAddin.object().openPage(name);
}
stdlib.createMacros(SelfScript.self, "Горячие клавиши Снегопата", "Открыть горячие клавиши Снегопата", undefined, function () { openSnegopatPage("Hotkeys"); });
stdlib.createMacros(SelfScript.self, "Выбор скриптов", "Открыть окно выбора загружаемых скриптов", undefined, function () {
    var a = addins.byUniqueName("select_scripts");
    if (a)
        a.object().openForm();
});
stdlib.createMacros(SelfScript.self, "Справка Снегопата", "Открыть справку Снегопата", undefined, function () { openSnegopatPage("Help"); });
stdlib.createMacros(SelfScript.self, "О программе Снегопат", "Открыть сведения о Снегопате", undefined, function () { openSnegopatPage("About"); });
stdlib.createMacros(SelfScript.self, "Показать список методов модуля", "Открыть диалог со списком методов редактируемого модуля", stdcommands.Frntend.MDReport.info.picture, function () { snegopat.showMethodsList; }, "Ctrl + 1|Ctrl + Alt + P");
stdlib.createMacros(SelfScript.self, "Вернуться назад", "Перейти назад по истории окон", stdcommands.Frame.GotoBack.info.picture, function () { stdcommands.Frame.GotoBack.send(); }, "Alt+Left");
stdlib.createMacros(SelfScript.self, "Перейти вперёд", "Перейти вперёд по истории окон", stdcommands.Frame.GotoForward.info.picture, function () { stdcommands.Frame.GotoForward.send; }, "Alt+Right");
stdlib.createMacros(SelfScript.self, "ПоказатьВыпадающийСписокСнегопата", "Принудительно вызвать список снегопата, всё перепарсив", stdcommands.Config.SyntaxHelper.info.picture, function () { return snegopat.showSmartBox(); }, "Ctrl+Alt+Space");
function replaceSelInTxtWnd(textBefore, textAfter, activateHint) {
    var txtWnd = snegopat.activeTextWindow();
    if (!txtWnd) {
        if (textBefore.length > 0 && !textAfter) {
            var h = winApi.getFocus();
            for (var i = 0; i < textBefore.length; i++)
                winApi.sendMessage(h, WM_CHAR, textBefore.charCodeAt(i), 0);
        }
        return false;
    }
    var oldText = txtWnd.selectedText;
    var newText = textBefore;
    if (textAfter.length)
        newText += oldText + textAfter;
    txtWnd.selectedText = newText;
    if (textAfter.length) {
        var cp = txtWnd.getCaretPos();
        txtWnd.setCaretPos(cp.beginRow, cp.beginCol - textAfter.length);
    }
    if (activateHint)
        snegopat.showSmartBox();
    return true;
}
stdlib.createMacros(SelfScript.self, "Перейти к определению", "Перейти к определению символа под курсором (аналог F12)", stdcommands.Frntend.GoToDefinition.info.picture, function () {
    if (snegopat.activeTextWindow() && windows.modalMode == msNone) {
        var st = stdcommands.Frntend.GoToDefinition.getState();
        if (st && st.enabled) {
            // Будем также подавлять появление дополнительного диалога
            var handler = events.connect(windows, "onDoModal", function (dlgInfo) {
                if (dlgInfo.stage == beforeDoModal) {
                    dlgInfo.cancel = true;
                    dlgInfo.result = 1;
                }
            }, "-");
            var res = stdcommands.Frntend.GoToDefinition.send();
            events.disconnectNode(handler);
            return res;
        }
    }
    return false;
}, "Ctrl + Enter");
stdlib.createMacros(SelfScript.self, "Выбрать подключаемые скрипты", "Открыть диалог для выбора загружаемых скриптов", undefined, function () {
    addins.byUniqueName("select_scripts").object().openForm();
});
stdlib.createMacros(SelfScript.self, "Приостановить стартер", "Временно приостанавливает подключение Core.As модулей к запускаемым программам", undefined, function () {
    starterIpc.setInjectStatus(false);
});
stdlib.createMacros(SelfScript.self, "Возобновить cтартер", "Возобновляет подключение Core.As модулей к запускаемым программам", undefined, function () {
    starterIpc.setInjectStatus(true);
});
// Метод вызывается при регистрации хоткеев аддина
function getPredefinedHotkeys(predef) {
    predef.setVersion(7);
    stdlib.getAllPredefHotKeys(SelfScript.self, predef);
}
// Настройка «Открывать окна развёрнутыми» (Snegopat/Settings/MaximizeWindows, галка на странице настроек):
// обычное MDI-окно документа разворачивается командой «Развернуть» (группа окна, №7).
// Срабатывание: движок оповещает windows.onViewOpened сразу после штатного открытия окна (engine/com_windows.as, перехват IBkEndUI::openView),
// но окно к этому моменту ещё не в режиме MDI (его модуль инициализируется после возврата). Поэтому после открытия и при смене
// активного окна проверяем состояние на простое (не чаще раза в 100 мс, до 1,5 с) и разворачиваем, как только окно стало MDI.
(function () {
    // ключ создаётся один раз (по умолчанию выключено) — setValue на несуществующий ключ ничего не пишет
    profileRoot.createValue("Snegopat/Settings/MaximizeWindows", false, pflSnegopat);
    var optionKey = "Snegopat/Settings/MaximizeWindows";
    var lastViewId = "";
    var checkUntil = 0, lastCheckAt = 0;
    // «Развернуть» — только через главное окно (оно адресует активное MDI-окно; дерево и панели
    // остаются на месте). Команда, посланная самому окну редактора объекта, включает у него режим
    // «на всё окно Конфигуратора» поверх панелей — так не надо.
    // mdiMax у текстовых окон не обновляется — не проверяем, повторное «Развернуть» безвредно.
    // true, если окно в режиме MDI и команда отправлена.
    function tryMaximize() {
        lastCheckAt = new Date().getTime();
        try {
            var view = windows.getActiveView();
            if (!view)
                return false;
            var pos = view.position();
            if (pos && pos.state == 4 /* vsMDI */) {
                sendCommand("{c9d3c390-1eb4-11d5-bf52-0050bae2bc79}", 7);
                return true;
            }
        } catch (e) { }
        return false;
    }
    function startChecking() {
        checkUntil = new Date().getTime() + 1500;
    }
    events.connect(windows, "onViewOpened", function () {
        if (!profileRoot.getValue(optionKey))
            return;
        startChecking();
        if (tryMaximize())
            checkUntil = 0;
    }, "-");
    events.connect(Designer, "onIdle", function () {
        var view = null;
        try { view = windows.getActiveView(); } catch (e) { return; }
        if (!view)
            return;
        var id = "";
        try { id = String(view.id); } catch (e) { }
        if (id != lastViewId) {
            lastViewId = id;
            if (profileRoot.getValue(optionKey))
                startChecking();
        }
        if (!checkUntil)
            return;
        var now = new Date().getTime();
        if (now >= checkUntil) {
            checkUntil = 0;
            return;
        }
        if (now - lastCheckAt >= 100 && tryMaximize())
            checkUntil = 0;
    }, "-");
})();
// Настройка «Открывать расширения закладками в окне Конфигурация» (Snegopat/Settings/ExtensionsInConfigWindow, галка на странице настроек):
// окно расширения («Конфигурация» расширения) прикрепляется закладкой к окну «Конфигурация» основной конфигурации, как у «Внешних файлов»
// и «Панели окон» (IV8View.merge(окно, 32)). Включённая галка действует и на уже открытые расширения (следующий проход на простое).
// Окно расширения узнаём по контейнеру: корневое окно контейнера-расширения (masterContainer или идентификатор «Расширение конфигурации "…"»),
// внешние обработки, cf и конфигурация БД не трогаем. Обход окон идёт COM-вызовами платформы, поэтому только при открытии окна (windows.onViewOpened) и при включённой галке;
// каждое окно прикрепляем один раз за сеанс (если пользователь потом вытащил его, не возвращаем).
(function () {
    var optionKey = "Snegopat/Settings/ExtensionsInConfigWindow"
    var lastPassAt = 0
    var handled = {}
    var openedCount = 0
    profileRoot.createValue(optionKey, false, pflSnegopat)
    var configId = ""           // id окна «Конфигурация» основной конфигурации: его объект меняется при выборе узла в дереве, по корню окно потом не узнать
    var extIds = {}             // id окон расширений, уже опознанных по корню
    function rootId(container) {
        return String(container.rootObject.id)
    }
    // Окно-дерево: окно с mdObj, id которого равен id корневого объекта своего контейнера
    function isRootWindow(obj, container) {
        return String(obj.id) == rootId(container)
    }
    // Расширение: у контейнера есть главный контейнер (masterContainer) или идентификатор «Расширение конфигурации "Имя"».
    // Проверено по журналу на 8.3.17: контейнеры расширений входят в metadata.getContainer(i) наравне с внешними обработками, исключать «известные» нельзя
    function isExtensionContainer(container, cid) {
        // Внешняя обработка или отчёт (идентификатор контейнера — путь к файлу .epf/.erf) тоже имеет masterContainer,
        // но расширением не является: её окно к окну «Конфигурация» не прикрепляем.
        if (/\.(epf|erf)\s*$/i.test(cid))
            return false
        try { if (container.masterContainer) return true } catch (e) { }
        return /^Расширение конфигурации/i.test(cid)
    }
    var lastReport = ""
    // Диагностика в script-log (категория extwin): что нашли и чем кончилась привязка; строка пишется только при изменении
    function report(text) {
        if (text == lastReport)
            return
        lastReport = text
        try { snegopat.diagLog("extwin", text) } catch (e) { }
    }
    function describe(view) {
        var s = ""
        try { s = "«" + view.title + "»" } catch (e) { s = "«?»" }
        try { s += " id=" + view.id } catch (e) { }
        try { s += " область=" + view.position().area } catch (e) { s += " область=?" }
        try { s += " родитель=" + view.parent.id } catch (e) { s += " родитель=?" }
        return s
    }
    function attachExtensions() {
        var configView = null, extViews = [], seenRoots = []
        walkWindowTree(function (view) {
            var obj = null, container = null, cid = "", title = ""
            try { obj = view.mdObj } catch (e) { }
            if (!obj)
                return
            try { container = obj.container } catch (e) { }
            if (!container)
                return
            try { cid = container.identifier } catch (e) { }
            try { title = String(view.title) } catch (e) { }
            var vid = String(view.id), root = false
            try { root = isRootWindow(obj, container) } catch (e) { }
            if (container == metadata.current) {
                // «Конфигурация»: по корню, по запомненному id или по заголовку (объект окна меняется при выборе узла)
                if (root || vid == configId || title == "Конфигурация") {
                    configView = view
                    configId = vid
                    seenRoots.push("основная: " + describe(view))
                }
            } else if (isExtensionContainer(container, cid)) {
                if (root || extIds[vid]) {
                    extIds[vid] = true
                    extViews.push(view)
                    seenRoots.push("расширение: " + describe(view) + " контейнер=" + cid)
                }
            }
        })
        if (!configView) {
            report("окно «Конфигурация» основной конфигурации не найдено; окон-корней: " + seenRoots.length + " [" + seenRoots.join("; ") + "]")
            return
        }
        var results = []
        for (var n = 0; n < extViews.length; n++) {
            var id = String(extViews[n].id)
            var seen = handled[id]
            if (!seen)
                seen = handled[id] = { merges: 0 }
            // Окно прикрепляем при открытии; дальше его положение определяет пользователь (вытащенное вручную не возвращаем)
            if (seen.done || seen.merges >= 3)
                continue
            try {
                if (String(extViews[n].parent.id) == String(configView.parent.id)) {
                    seen.done = true
                    continue
                }
                // merge на самом окне «Конфигурация» каждый раз оборачивает его в новую группу (получались вложенные ряды закладок),
                // поэтому, когда окно уже в группе закладок (isContainer == 1), закладка добавляется через merge на этой группе
                var group = null, inTabs = false
                try { group = configView.parent; inTabs = Number(group.isContainer) == 1 } catch (e) { }
                if (inTabs)
                    group.merge(extViews[n], 32)
                else
                    configView.merge(extViews[n], 32)
                seen.merges++
                seen.done = String(extViews[n].parent.id) == String(configView.parent.id)
                results.push("merge №" + seen.merges + ": " + describe(extViews[n]) + " общий родитель после=" + seen.done)
            } catch (e) {
                seen.merges++
                results.push("ошибка merge: " + describe(extViews[n]) + ": " + e.message)
            }
        }
        report("открытий окон: " + openedCount + "; корни окон: [" + seenRoots.join("; ") + "]" + (results.length ? " итог: " + results.join(" | ") : ""))
    }
    function walkWindowTree(fn) {
        (function walk(view, depth) {
            if (!view || depth > 10)
                return
            var title = ""
            try { title = view.title } catch (e) { }
            if (title && !view.isContainer)
                fn(view)
            try {
                var childs = view.enumChilds()
                for (var i = 0; i < childs.count; i++)
                    walk(childs.item(i), depth + 1)
            } catch (e) { }
        })(windows.mainView, 0)
    }
    // Срабатывание: движок оповещает windows.onViewOpened сразу после штатного открытия окна (engine/com_windows.as, перехват IBkEndUI::openView),
    // проход идёт тут же, до перерисовки. Если окно ещё не готово, повторяем на простое в течение 1,5 с (не чаще раза в 100 мс).
    // Опроса по времени нет. При включении галки один проход делаем на ближайшем простом (уже открытые расширения).
    var retryUntil = 0
    var optionWasOn = false
    function pass() {
        lastPassAt = new Date().getTime()
        try { attachExtensions() } catch (e) { }
    }
    events.connect(windows, "onViewOpened", function () {
        if (!profileRoot.getValue(optionKey))
            return
        openedCount++
        pass()
        retryUntil = lastPassAt + 1500
    }, "-")
    events.connect(Designer, "onIdle", function () {
        var on = profileRoot.getValue(optionKey)
        if (!on) {
            handled = {}        // повторное включение галки прикрепит расширения заново
            optionWasOn = false
            return
        }
        var now = new Date().getTime()
        if (!optionWasOn) {
            optionWasOn = true
            retryUntil = now + 1500
        }
        if (now < retryUntil && now - lastPassAt >= 100)
            pass()
    }, "-")
})();
var starterNotifyTimer = 0
function hideStartNotify() {
    try { killTimer(starterNotifyTimer) } catch (e) { }
    try { starterIpc.showNotify("", "") } catch (e) { }
}
(function () {
    // Уведомление «К базе подключён Снегопат» отключено (просьба владельца 2026-10-24): и так видно, что Снегопат подключился,
    // по пункту «Снегопат» в главном меню Конфигуратора. Флажок «ShowNotifyOnStartup» в настройках пока ничего не делает.
    // Чтобы вернуть: раскомментировать блок ниже.
    /*
    if (profileRoot.getValue("Snegopat/Settings/ShowNotifyOnStartup")) {
        starterIpc.showNotify("Снегопат Core " + env.sVersion + " (" + env.arch + ")", "К " + stdlib.ibName() + " подключен Снегопат");
        // Уведомление о подключении Снегопата показывает стартер (всплывающая подсказка системы), оно висит несколько секунд —
        // через 1 секунду гасим: пустое уведомление убирает текущее
        starterNotifyTimer = createTimer(1000, SelfScript.self, "hideStartNotify")
    }
    */
    /*events.connect(starterIpc, "Broadcast", function (sbc) {
        Message("Получена рассылка. От=" + sbc.source + " Данные=" + sbc.data);
    }, "-");*/
})();
